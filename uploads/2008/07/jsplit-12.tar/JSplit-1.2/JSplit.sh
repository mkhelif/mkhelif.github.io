#!/bin/sh
java -jar lib/JSplit-1.2.jar