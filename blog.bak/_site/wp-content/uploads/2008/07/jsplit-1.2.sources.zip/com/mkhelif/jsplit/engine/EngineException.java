package com.mkhelif.jsplit.engine;

/**
 * @author Marwan KHELIF
 * @version Version 1.0 - 05/03/2007 
 */
public class EngineException extends Exception {
	private static final long serialVersionUID = 1L;

	public EngineException () {
	} // EngineException ()

	public EngineException (String msg) {
		super (msg);
	} // EngineException ()

	public EngineException (Throwable err) {
		super (err);
	} // EngineException ()

	public EngineException (String msg, Throwable err) {
		super (msg, err);
	} // EngineException ()
} // EngineException