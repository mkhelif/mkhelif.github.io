package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class TurboCutFile extends DefaultStickEngine {
	
	public TurboCutFile (File file) {
		super (file);
	} // TurboCutFile ()

	protected void loadHeaders () throws IOException, FileNotFoundException {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile (file, "r");
			
			// Get filename :
			fileName = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().lastIndexOf ("."));
			
			// Retreive parts number :
			byte[] b = new byte[3];
			raf.read (b);
			parts = Integer.parseInt (new String (b));
						
			// Retreive file length :
			b = new byte[15];
			raf.read (b);
			fileLength = Integer.parseInt (new String (b)) - 18;
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { raf.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 0 ; i < getParts () ; ) {
				RandomAccessFile access = new RandomAccessFile (getFileName () + ".TCF" + i, "r");
				long read = 0;
				long length = access.length ();
				
				if (i == 0) {
					// Skip headers :
					access.skipBytes (18);
					fireEngineDone (18);
					read += 18;
				}
				
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded (((++i + 1) > getParts () ? -1 : i + 1));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // TurboCutFile