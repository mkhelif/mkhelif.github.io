package com.mkhelif.jsplit.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.engine.stick.DefaultStickEngine;

/**
 * @author Marwan KHELIF
 */
public class StickPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private JLabel sizeLabel = null;
	private JLabel size = null;
	private JLabel partLabel = null;
	private JLabel part = null;
	private JLabel nameLabel = null;
	private JLabel name = null;
	
	public StickPanel () {
		super ();
		initialize ();
	} // StickPanel ()

	private void initialize () {
		this.setLayout (new GridBagLayout ());
		GridBagConstraints c = new GridBagConstraints ();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        
        // Create components :
        nameLabel = new JLabel (i18n ("stick.name"), JLabel.RIGHT);
        name = new JLabel ("", JLabel.LEFT);
        
        sizeLabel = new JLabel (i18n ("stick.size"), JLabel.RIGHT);
        size = new JLabel ("", JLabel.LEFT);
        
        partLabel = new JLabel (i18n ("stick.part"), JLabel.RIGHT);
        part = new JLabel ("", JLabel.LEFT);
        
        // Layout components :
        c.insets = new Insets (5, 5, 2, 2);
        c.gridx = 0;
        c.gridy = 0;
        this.add (nameLabel, c);

        c.insets = new Insets (5, 0, 0, 0);
        c.gridx = 1;
        c.gridy = 0;
        this.add (name, c);
        
        c.insets = new Insets (5, 5, 2, 2);
        c.gridx = 0;
        c.gridy = 1;
        this.add (sizeLabel, c);

        c.insets = new Insets (5, 0, 0, 0);
        c.gridx = 1;
        c.gridy = 1;
        this.add (size, c);

        c.insets = new Insets (5, 5, 2, 2);
        c.gridx = 0;
        c.gridy = 2;
        this.add (partLabel, c);

        c.insets = new Insets (5, 0, 0, 0);
        c.gridx = 1;
        c.gridy = 2;
        this.add (part, c);
        
        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 1;
        this.add (new JPanel (), c);
	} // initialize ()
		
	public void load (File file) {
		DefaultStickEngine engine = DefaultStickEngine.getInstance (file);
		if (engine == null) {
			return;
		}
		
		String fs = "";
		if (engine.getFileLength () >= 100000000) {
			fs = engine.getFileLength () / 1000000 + " Mb";
		} else if (engine.getFileLength () >= 100000) {
			fs = engine.getFileLength () / 1000 + " Kb";
		} else {
			fs = engine.getFileLength () + " b";
		}

		name.setText (new File (engine.getFileName ()).getName ());
		size.setText (fs);
		part.setText (String.valueOf (engine.getParts ()));
		
		Workbench.getInstance ().getProgress ().setMaximum (engine.getFileLength ());
		Workbench.getInstance ().setEngine (engine);
	} // load ()
		
	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // StickPanel