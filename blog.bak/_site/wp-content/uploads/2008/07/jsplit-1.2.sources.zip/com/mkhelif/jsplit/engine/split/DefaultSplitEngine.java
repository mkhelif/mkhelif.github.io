package com.mkhelif.jsplit.engine.split;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.mkhelif.jsplit.engine.DefaultEngine;
import com.mkhelif.jsplit.engine.EngineException;
import com.mkhelif.jsplit.gui.DefaultEngineListener;

/**
 * @author Marwan KHELIF
 */
public abstract class DefaultSplitEngine extends DefaultEngine {

	protected File file = null;
	protected int parts = -1;
	
	public DefaultSplitEngine (File file, int parts) {
		super ();
		this.file = file;
		this.parts = parts;
	} // DefaultSplitEngine ()
	
	public void run () {
		synchronized (mutex) {
			try {
				split ();
			} catch (Exception e) {
				fireEngineError (new EngineException (e));
			}
		}
	} // run ()
	
	public abstract void split () throws IOException, FileNotFoundException;
	
	/*
	 * Events methods :
	 */
	protected void fireEnginePartEnded (int next) {
		DefaultEngineListener.getInstance ().enginePartEnded (next);
	} // fireEnginePartEnded ()

	protected void fireEngineEnded () {
		DefaultEngineListener.getInstance ().engineEnded ();
	} // fireEngineEnded ()

	protected void fireEngineError (EngineException exc) {
		DefaultEngineListener.getInstance ().engineError (exc);
	} // fireEngineError ()
	
	protected void fireEngineDone (long readed) {
		DefaultEngineListener.getInstance ().engineDone (readed);
	} // fireEngineReaded ()
} // DefaultSplitEngine