package com.mkhelif.jsplit;

import com.mkhelif.jsplit.gui.Workbench;

/**
 * @author Marwan KHELIF
 * @version Version 1.0 - 05/03/2007 
 */
public class Launcher {

	public static void start () {
		Workbench.getInstance ().setVisible (true);
	} // start ()
	
	public static void stop () {
		
		System.exit (0);
	} // stop ()
	
	public static void main (String[] args) {
		Launcher.start ();
	} // main ()
} // Launcher