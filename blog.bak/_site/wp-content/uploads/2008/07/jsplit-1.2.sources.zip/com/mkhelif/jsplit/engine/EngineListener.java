package com.mkhelif.jsplit.engine;

/**
 * @author Marwan KHELIF
 */
public interface EngineListener {
	public void enginePartEnded (int next);
	public void engineEnded ();
	
	public void engineError (EngineException exc);
	
	public void engineDone (long readed);
} // EngineListener