package com.mkhelif.jsplit.engine.stick;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class Scieber extends DefaultStickEngine {

	public Scieber (File file) {
		super (file);
	} // Scieber ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader (new FileReader (file));
			
			// Read the only line of the file :
			String line = reader.readLine ();
			
			parts = Integer.parseInt (line.split ("�")[0]);
			line = line.replace (parts + "�", "");
			fileName = file.getAbsolutePath ().replace (file.getName (), "") + line.split ("�")[0];
			fileLength = Integer.parseInt (line.split ("�")[1]);
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { reader.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		String part = file.getAbsolutePath ().replace (file.getName (), "") + file.getName ().replace ("_infos.sci", "");
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 1 ; i <= getParts () ; ) {
				RandomAccessFile access = new RandomAccessFile (part + "_" + i + ".sci", "r");
				long read = 0;
				long length = access.length ();
								
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded ((++i > getParts () ? -1 : i));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // Scieber