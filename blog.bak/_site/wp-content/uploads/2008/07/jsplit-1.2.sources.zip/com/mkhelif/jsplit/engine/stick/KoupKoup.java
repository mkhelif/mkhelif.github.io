package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class KoupKoup extends DefaultStickEngine {
	
	public KoupKoup (File file) {
		super (file);
	} // KoupKoup ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {		
		FileReader reader = null;
		try {
			fileName = file.getAbsolutePath ().replace (file.getName (), "") + file.getName ().substring (0, file.getName ().lastIndexOf ("."));
			
			// Read parts :
			reader = new FileReader (file);
			parts = Integer.parseInt (new String (new byte[] {(byte) reader.read ()}));
			
			// Calculate length :
			for (int i = 1 ; i <= getParts () ; i++) {
				fileLength += new File (getFileName () + "." + i).length ();
			}
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { reader.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 1 ; i <= getParts () ; ) {
				RandomAccessFile access = new RandomAccessFile (getFileName () + "." + i, "r");
				long read = 0;
				long length = access.length ();
				
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded ((++i > getParts () ? -1 : i));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // KoupKoup