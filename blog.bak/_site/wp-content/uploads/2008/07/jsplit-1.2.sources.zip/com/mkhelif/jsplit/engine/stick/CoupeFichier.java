package com.mkhelif.jsplit.engine.stick;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class CoupeFichier extends DefaultStickEngine {

	public CoupeFichier (File file) {
		super (file);
	} // CoupeFichier ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader (new FileReader (file));
			
			// Read file name :
			fileName = reader.readLine ();
			
			// Retreive parts number :
			parts = Integer.parseInt (reader.readLine ().trim ());
						
			// Retreive file length :
			fileLength = Integer.parseInt (reader.readLine ().trim ());
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { reader.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		String part = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().length () - 4);
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 1 ; i <= getParts () ; ) {
				String current = (i >= 1000 ? String.valueOf (i) : (i >= 100 ? "0" + i : (i >= 10 ? "00" + i : "000" + i)));
				RandomAccessFile access = new RandomAccessFile (part + current, "r");
				long read = 0;
				long length = access.length ();
								
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded ((++i > getParts () ? -1 : i));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // CoupeFichier