package com.mkhelif.jsplit.gui.action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.Launcher;

/**
 * @author Marwan KHELIF
 */
public class CloseAction extends AbstractAction {
	private static final long serialVersionUID = 1L;

	private static final String TEXT = i18n ("close");

	public CloseAction () {
		super (TEXT);
	} // CloseAction ()
	
	public void actionPerformed (ActionEvent evt) {
		Launcher.stop ();
	} // actionPerformed ()

	private static String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // CloseAction