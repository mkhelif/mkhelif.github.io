package com.mkhelif.jsplit.gui.action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.gui.Workbench;

/**
 * @author Marwan KHELIF
 */
public class PauseAction extends AbstractAction {
	private static final long serialVersionUID = 1L;

	private static final String TEXT = i18n ("pause");
	
	public PauseAction () {
		super (TEXT);
	} // PauseAction ()

	public void actionPerformed (ActionEvent evt) {
		Workbench.getInstance ().getEngine ().pause ();
		Workbench.getInstance ().getBottom ().getGo ().setAction (new ResumeAction ());
	} // actionPerformed ()
	
	private static String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // PauseAction