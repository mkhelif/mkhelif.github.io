package com.mkhelif.jsplit.gui.action;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.engine.split.XtremSplit;
import com.mkhelif.jsplit.gui.Workbench;

/**
 * @author Marwan KHELIF
 */
public class SplitAction extends AbstractAction {
	private static final long serialVersionUID = 1L;

	private static final String TEXT = i18n ("split");
	
	public SplitAction () {
		super (TEXT);
	} // SplitAction ()

	public void actionPerformed (ActionEvent evt) {
		File file = new File (Workbench.getInstance ().getSelection ().getFile ().getText ());

		// Verify that the selected file exists :
		if (!file.exists ()) {
			JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("error.notfound"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
			return;
		}
		
		// Calculate parts number :
		int parts = 0;
		if (Workbench.getInstance ().getSplit ().getByParts ().isSelected ()) {
			try {
				parts = Integer.parseInt (Workbench.getInstance ().getSplit ().getParts ().getText ());
			} catch (NumberFormatException e) {
				JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("error.format"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
				return;
			}
		} else {
			int subLength = 0;
			try {
				subLength = Integer.parseInt (Workbench.getInstance ().getSplit ().getLength ().getText ());
			} catch (NumberFormatException e) {
				JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("error.format"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
				return;
			}
			parts = (int) (file.length () / subLength); 
		}
		
		Workbench.getInstance ().getBottom ().getGo ().setAction (new PauseAction ());
		Workbench.getInstance ().getProgress ().setMaximum ((int) file.length ());
		Workbench.getInstance ().setEnabled (false);
		
		new Thread (new XtremSplit (file, parts), "Split - " + file.getName ()).start ();
	} // actionPerformed ()
		
	private static String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // SplitAction