package com.mkhelif.jsplit.engine;

/**
 * @author Marwan KHELIF
 */
public abstract class DefaultEngine implements Engine {

	protected static final int BUFFER = 16384;
		
	protected final Object mutex = new Object ();
	protected boolean paused = false;
	
	public abstract void run ();
	
	public void pause () {
		paused = true;
	} // pause ()

	public void resume () {
		synchronized (mutex) {
			paused = false;
			mutex.notify ();
		}
	} // resume ()
} // DefaultEngine