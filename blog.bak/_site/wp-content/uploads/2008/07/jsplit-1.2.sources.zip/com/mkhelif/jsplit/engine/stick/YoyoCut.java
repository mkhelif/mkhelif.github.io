package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

/**
 * @author Marwan KHELIF
 */
public class YoyoCut extends DefaultStickEngine {

	private int headersLength = 0;
	
	public YoyoCut (File file) {
		super (file);
	} // YoyoCut ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile (file, "r");
			
			// Read file extension :
			ByteBuffer ext = ByteBuffer.allocate (10);
			byte[] b = new byte[1];
			while (b[0] != 32) {
				raf.read (b);
				ext.put (b);
			}
			
			headersLength = ext.array ().length;
			fileName = file.getAbsolutePath ();
			fileName = fileName.substring (0, fileName.length () - 7);
			fileName += new String (ext.array ()).trim ();
			
			// Retreive parts number :
			b = new byte[3];
			raf.read (b);
			parts = Integer.parseInt (new String (b));
			headersLength += 3;
			
			// Is MD5 present :
			b = new byte[4];
			raf.read (b);
			if (new String (b).equals ("MD5:")) {
				md5 = true;
				headersLength += 32;
			}
			headersLength += 4;
			
			// Retreive file length :
			String part = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().length () - 7);
			for (int i = 1 ; i <= getParts () ; ++i) {
				String current = (i >= 100 ? String.valueOf (i) : (i >= 10 ? "0" + i : "00" + i));
				File next = new File (part + current + ".yct");
				fileLength += next.length ();
			}
			fileLength -= headersLength;
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { raf.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		String part = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().length () - 7);
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 1 ; i <= getParts () ; ) {
				String current = (i >= 100 ? String.valueOf (i) : (i >= 10 ? "0" + i : "00" + i));
				RandomAccessFile access = new RandomAccessFile (part + current + ".yct", "r");
				long read = 0;
				long length = access.length ();
				
				if (i == 1) {
					// Skip headers :
					access.skipBytes (headersLength);
					fireEngineDone (headersLength);
					read += headersLength;
				}
				
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded ((++i > getParts () ? -1 : i));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // YoyoCut