package com.mkhelif.jsplit.gui;

import javax.swing.JOptionPane;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.engine.EngineException;
import com.mkhelif.jsplit.engine.EngineListener;
import com.mkhelif.jsplit.gui.action.SplitAction;
import com.mkhelif.jsplit.gui.action.StickAction;

/**
 * @author Marwan KHELIF
 */
public class DefaultEngineListener implements EngineListener {

	private static DefaultEngineListener listener = null;
	
	private DefaultEngineListener () {} // DefaultEngineListener ()
	
	public static DefaultEngineListener getInstance () {
		if (listener == null) {
			listener = new DefaultEngineListener ();
		}
		return listener;
	} // getInstance ()

	public void engineEnded () {
		if (Workbench.getInstance ().getSelection ().getStick ().isSelected ()) {
			JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("stick.ended"), i18n ("stick.end"), JOptionPane.DEFAULT_OPTION);
		} else {
			JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("split.ended"), i18n ("stick.end"), JOptionPane.DEFAULT_OPTION);
		}
		
		Workbench.getInstance ().getProgress ().setString (i18n ("stick.end"));
		Workbench.getInstance ().getProgress ().setValue (0);
		
		if (Workbench.getInstance ().getSelection ().getSplit ().isSelected ()) {
			Workbench.getInstance ().getBottom ().getGo ().setAction (new SplitAction ());
		} else {
			Workbench.getInstance ().getBottom ().getGo ().setAction (new StickAction ());
		}
		
		Workbench.getInstance ().setEnabled (true);
	} // engineEnded ()

	public void engineError (EngineException exc) {
		JOptionPane.showConfirmDialog (Workbench.getInstance (), exc.getMessage (), i18n ("error"), JOptionPane.DEFAULT_OPTION);
		
		Workbench.getInstance ().getProgress ().setString (i18n ("error"));
		Workbench.getInstance ().getProgress ().setValue (0);
		
		Workbench.getInstance ().setEnabled (true);
	} // engineError ()

	public void enginePartEnded (int next) {
		if (next == -1) {
			return;
		}
		Workbench.getInstance ().getProgress ().setString (i18n ("part") + next);
	} // enginePartEnded ()

	public void engineDone (long readed) {
		Workbench.getInstance ().getProgress ().setValue (Workbench.getInstance ().getProgress ().getValue () + (int) readed);
	} // engineReaded ()

	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // DefaultEngineListener