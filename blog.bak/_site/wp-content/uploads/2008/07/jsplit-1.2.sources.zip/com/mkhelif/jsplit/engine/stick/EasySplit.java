package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class EasySplit extends DefaultStickEngine {

	public EasySplit (File file) {
		super (file);
	} // EasySplit ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile (file, "r");
			
			// Skip program name :
			byte[] b = new byte[7];
			raf.read (b);
			
			// Retreive parts number :
			b = new byte[3];
			raf.read (b);
			b = new byte[3];
			raf.read (b);
			parts = Integer.parseInt (new String (b));
			
			// Read file extension :
			b = new byte[3];
			raf.read (b);
			fileName = file.getAbsolutePath ();
			fileName = fileName.substring (0, fileName.length () - 3);
			fileName += new String (b).trim ();
			
			// Retreive file length :
			String part = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().length () - 3);
			for (int i = 0 ; i < getParts () ; ++i) {
				String current = (i >= 100 ? String.valueOf (i) : (i >= 10 ? "0" + i : "00" + i));
				File next = new File (part + current);
				fileLength += next.length ();
			}
			fileLength -= 16;
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { raf.close (); } catch (IOException e) {}
		}
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		String part = file.getAbsolutePath ().substring (0, file.getAbsolutePath ().length () - 3);
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 0 ; i < getParts () ; ) {
				String current = (i >= 100 ? String.valueOf (i) : (i >= 10 ? "0" + i : "00" + i));
				RandomAccessFile access = new RandomAccessFile (part + current, "r");
				long read = 0;
				long length = access.length ();
				
				// Skip headers :
				access.skipBytes (16);
				fireEngineDone (16);
				read += 16;
				
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded (((++i + 1) > getParts () ? -1 : i + 1));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // EasySplit