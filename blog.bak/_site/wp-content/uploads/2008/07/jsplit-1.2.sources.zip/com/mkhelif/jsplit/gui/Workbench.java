package com.mkhelif.jsplit.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.dnd.DropTarget;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.TooManyListenersException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.UIManager;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.Launcher;
import com.mkhelif.jsplit.engine.Engine;

/**
 * @author Marwan KHELIF
 * @version Version 1.0 - 05/03/2007 
 */
public class Workbench extends JFrame {
	private static final long serialVersionUID = 1L;

	public static final String VERSION = "jSplit 1.2";
	
	private static Workbench workbench = null;
	
	private Workbench () {
		super (VERSION);
		initialize ();
	} // Workbench ()
	
	public static Workbench getInstance () {
		if (workbench == null) {
			workbench = new Workbench ();
		}
		return workbench;
	} // getInstance ()
	
	private Engine engine = null;
	
	private TopInfoPanel infos = null;
	private SelectionPanel selection = null;
	
	private SplitPanel split = null;
	private StickPanel stick = null;
	
	private JProgressBar progress = null;
	private BottomPanel buttons = null;
	
	private void initialize () {
		// Change default LookAndFeel :
        try {
            UIManager.setLookAndFeel (UIManager.getSystemLookAndFeelClassName ());
        } catch (Exception e) {}
		
        // Layout components :
        this.setContentPane (new JPanel ());
        this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        
        c.gridy = 0;
        this.add (getInfos (), c);
        
        c.gridy = 1;
        this.add (getSelection (), c);
    
        c.gridy = 2;
        this.add (getSplit (), c);
        this.add (getStick (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridy = 3;
        c.weighty = 1;
        this.add (new JPanel (), c);
        c.weighty = 0;
        
        c.insets = new Insets (3, 2, 3, 2);
        c.gridy = 4;
        this.add (getProgress (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridy = 5;
        this.add (new JSeparator (), c);

        c.gridy = 6;
        this.add (getBottom (), c);
        
        this.pack ();
        this.setLocationRelativeTo (null);
        this.setIconImage (new ImageIcon (getClass ().getResource ("images/files.png")).getImage ());
        this.addWindowListener (new WindowAdapter () {
            public void windowClosing (WindowEvent arg0) {
                Launcher.stop ();
            } // windowClosing ()
        });

        // Enable file Drag and Drop from system : 
        DropTarget target = new DropTarget ();
        try {
            target.addDropTargetListener (new SystemHandler ());
        } catch (TooManyListenersException e) {}
        this.setDropTarget(target);
	} // initialize ()
	
	public TopInfoPanel getInfos () {
		if (infos == null) {
			infos = new TopInfoPanel ();
			infos.setTitle (i18n ("infos.split.title"));
			infos.setInfo (i18n ("infos.split.info"));
		}
		return infos;
	} // getInfos ()
	
	public SelectionPanel getSelection () {
		if (selection == null) {
			selection = new SelectionPanel ();
		}
		return selection;
	} // getSelection ()
	
	public SplitPanel getSplit () {
		if (split == null) {
			split = new SplitPanel ();
		}
		return split;
	} // getSplit ()
	
	public StickPanel getStick () {
		if (stick == null) {
			stick = new StickPanel ();
			stick.setVisible (false);
		}
		return stick;
	} // getStick ()
	
	public JProgressBar getProgress () {
		if (progress == null) {
			progress = new JProgressBar ();
			progress.setString ("");
			progress.setStringPainted (true);
		}
		return progress;
	} // getProgress ()
	
	public BottomPanel getBottom () {
		if (buttons == null) {
			buttons = new BottomPanel ();
		}
		return buttons;
	} // getButtons ()
	
	public void setEnabled (boolean b) {
		getSelection ().setEnabled (b);
		getBottom ().setEnabled (b);
	} // setEnabled ()
	
	public Engine getEngine () {
		return engine;
	} // getEngine ()
	
	public void setEngine (Engine engine) {
		this.engine = engine;
	} // setEngine ()
	
	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // Workbench