package com.mkhelif.jsplit.engine;

/**
 * @author Marwan KHELIF
 */
public class ByteUtils {

	public static int toInt (byte[] b) {
		int value = 0;
		int exp = 0;
		for (int i = 0 ; i < b.length ; i++) {
			value += b[i] << exp;
			exp += 8;
		}
		return value;
	} // toInt ()
	
	public static byte[] toBytes (int num) {
		byte[] b = new byte[4];
		int exp = 3 * 8;
		for (int i = b.length  - 1; i >= 0 ; i--) {
			b[i] = (byte) (num << exp);
			exp -= 8;
		}
		return b;
	} // toBytes ()
	
	public static long toLong (byte[] b) {
		long value = 0;
		int exp = 0;
		for (int i = 0 ; i < b.length ; i++) {
			value += (((long) b[i]) & 0xFF) << exp;
			exp += 8;
		}
		return value;
	} // toLong ()
	
	public static byte[] toBytes (long num) {
		byte[] b = new byte[8];
		for (int i = 0 ; i < b.length ; i++) {
			b[i] = (byte) num;
			num >>>=8;
		}
		return b;
	} // toBytes ()
	
	public static boolean toBoolean (byte[] b) {
		return Boolean.parseBoolean (new String (b));
	} // toBoolean ()
} // ByteUtils