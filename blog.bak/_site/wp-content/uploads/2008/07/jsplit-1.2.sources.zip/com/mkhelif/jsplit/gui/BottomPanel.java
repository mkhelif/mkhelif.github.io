package com.mkhelif.jsplit.gui;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.gui.action.CloseAction;
import com.mkhelif.jsplit.gui.action.SplitAction;

/**
 * @author Marwan KHELIF
 */
public class BottomPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public static final String AUTHOR = "Marwan KHELIF - www.mkhelif.fr";

	private JButton go = null;
	private JButton close = null;

	public BottomPanel () {
		super ();
		initialize ();
	} // BottomPanel ()
	
	private void initialize () {
		this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0;
        
        JLabel about = new JLabel (AUTHOR);
		about.setFont (new Font ("", Font.PLAIN, 10));
		
		c.insets = new Insets (5, 5, 2, 0);
		this.add (about, c);
		c.weightx = 1;
		this.add (new JPanel (), c);
		
		c.weightx = 0;
		c.insets = new Insets (2, 2, 2, 2);
		this.add (getGo (), c);
		this.add (getClose (), c);
	} // initialize ()
	
	public JButton getGo () {
		if (go == null) {
			go = new JButton (new SplitAction ());
		}
		return go;
	} // getGo ()

	public JButton getClose () {
		if (close == null) {
			close = new JButton (new CloseAction ());
		}
		return close;
	} // getClose ()
	
	public void setEnabled (boolean b) {
		getClose ().setEnabled (b);
	} // setEnabled ()
		
	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // BottomPanel