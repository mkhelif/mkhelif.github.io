package com.mkhelif.jsplit.gui.action;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.engine.stick.DefaultStickEngine;
import com.mkhelif.jsplit.gui.Workbench;

/**
 * @author Marwan KHELIF
 */
public class StickAction extends AbstractAction {
	private static final long serialVersionUID = 1L;

	private static final String TEXT = i18n ("stick");

	public StickAction () {
		super (TEXT);
	} // StickAction ()

	public void actionPerformed (ActionEvent evt) {
		File file = new File (Workbench.getInstance ().getSelection ().getFile ().getText ());
		DefaultStickEngine engine = (DefaultStickEngine) Workbench.getInstance ().getEngine ();
		
		// Not supported format :
		if (engine == null) {
			JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("error.notsupported"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
			return;
		}
		
		// Verify that the selected file exists :
		if (!file.exists ()) {
			JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("error.notfound"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
			return;
		}
		
		// Verify that the file doesn't already exists :
		File neo = new File (engine.getFileName ());
		if (neo.exists ()) {
			int c = JOptionPane.showConfirmDialog (Workbench.getInstance (), i18n ("warning.exists"), i18n ("warning"), JOptionPane.OK_CANCEL_OPTION);
			if (c != JOptionPane.OK_OPTION) {
				return;
			}
		}
		
		Workbench.getInstance ().getBottom ().getGo ().setAction (new PauseAction ());
		Workbench.getInstance ().getProgress ().setMaximum ((int) engine.getFileLength ());
		Workbench.getInstance ().setEnabled (false);
		
		new Thread (engine, "Stick - " + neo.getName ()).start ();
	} // actionPerformed ()
	
	private static String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // StickAction