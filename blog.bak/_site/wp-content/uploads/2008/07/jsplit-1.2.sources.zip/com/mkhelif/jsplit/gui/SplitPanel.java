package com.mkhelif.jsplit.gui;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.mkhelif.jsplit.I18nManager;

/**
 * @author Marwan KHELIF
 */
public class SplitPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private JLabel splitLabel = null;
	private ButtonGroup group = null;
	
	private JPanel lengthPanel = null;
	private JRadioButton byLength = null;
	private JTextField length = null;
	
	private JPanel partsPanel = null;
	private JRadioButton byParts = null;
	private JTextField parts = null;
	
	public SplitPanel () {
		super ();
		initialize ();
	} // SplitPanel ()

	private void initialize () {
		this.setLayout (new GridBagLayout ());
		
		splitLabel = new JLabel (i18n ("split.method"), JLabel.RIGHT);
		
		group = new ButtonGroup ();
		group.add (getByLength ());
		group.add (getByParts ());
		group.setSelected (getByLength ().getModel (), true);
		
		// Layout components :
		this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        
        c.insets = new Insets (5, 10, 2, 2);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        this.add (splitLabel, c);

        c.insets = new Insets (-3, 5, 2, 2);
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 10;
        this.add (getLengthPanel (), c);

        c.insets = new Insets (-3, 5, 2, 2);
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 10;
        this.add (getPartsPanel (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        this.add (new JPanel (), c);
	} // initialize ()
	
	public JPanel getLengthPanel () {
		if (lengthPanel == null) {
			lengthPanel = new JPanel (new FlowLayout (FlowLayout.LEFT, 5, 2));
	        lengthPanel.add (getByLength ());
	        lengthPanel.add (getLength ());
	        lengthPanel.add (new JLabel (i18n ("split.unit")));
		}
		return lengthPanel;
	} // getLengthPanel ()

	public JRadioButton getByLength () {
		if (byLength == null) {
			byLength = new JRadioButton (i18n ("split.length"));
		}
		return byLength;
	} // getByLength ()
	
	public JTextField getLength () {
		if (length == null) {
			length = new JTextField ("15", 5);
		}
		return length;
	} // getLength ()
	
	public JRadioButton getByParts () {
		if (byParts == null) {
			byParts = new JRadioButton (i18n ("split.part"));
		}
		return byParts;
	} // getByParts ()
	
	public JPanel getPartsPanel () {
		if (partsPanel == null) {
			partsPanel = new JPanel (new FlowLayout (FlowLayout.LEFT, 5, 2));
	        partsPanel.add (getByParts ());
	        partsPanel.add (getParts ());
	        partsPanel.add (new JLabel (i18n ("split.parts")));
		}
		return partsPanel;
	} // getPartsPanel ()
	
	public JTextField getParts () {
		if (parts == null) {
			parts = new JTextField ("10", 5);
		}
		return parts;
	} // getParts ()
		
	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // SplitPanel