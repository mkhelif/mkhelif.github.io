package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.mkhelif.jsplit.engine.DefaultEngine;
import com.mkhelif.jsplit.engine.EngineException;
import com.mkhelif.jsplit.gui.DefaultEngineListener;

/**
 * @author Marwan KHELIF
 */
public abstract class DefaultStickEngine extends DefaultEngine {

	protected File file = null;
	
	protected String fileName = null;
	protected int fileLength = -1;
	protected int parts = -1;
	protected Boolean md5 = false;
	
	public DefaultStickEngine (File file) {
		super ();
		this.file = file;
		
		// Load headers :
		try { loadHeaders (); } 
		catch (Exception e) { fireEngineError (new EngineException (e)); }
	} // DefaultStickEngine ()
	
	/*
	 * Construct a real StickEngine :
	 */
	public static DefaultStickEngine getInstance (File file) {
		String name = file.getName ();
		if (name.endsWith (".001.xtm")) {
			return new XtremSplit (file);
		}
		if (name.endsWith (".001.yct")) {
			return new YoyoCut (file);
		}
		if (name.endsWith (".001")) {
			return new CutKiller (file);
		}
		if (name.endsWith (".000")) {
			return new EasySplit (file);
		}
		if (name.endsWith (".cpf")) {
			return new CoupeFichier (file);
		}
		if (name.endsWith (".kk0")) {
			return new KFK (file);
		}
		if (name.endsWith (".D00")) {
			return new DKoup (file);
		}
		if (name.endsWith (".spt")) {
			return new MaxSplit (file);
		}
		if (name.endsWith ("_infos.sci")) {
			return new Scieber (file);
		}
		if (name.endsWith (".TCF0")) {
			return new TurboCutFile (file);
		}
		if (name.endsWith (".d")) {
			return new Wind (file);
		}
		if (name.endsWith (".kop")) {
			return new KoupKoup (file);
		}
		return null;
	} // getInstance ()
	
	public void run () {
		synchronized (mutex) {
			try {
				stick ();
			} catch (Exception e) {
				fireEngineError (new EngineException (e));
			}
		}
	} // run ()
	
	protected abstract void loadHeaders () throws IOException, FileNotFoundException;
	public abstract void stick () throws IOException, FileNotFoundException;
	
	/*
	 * Getters :
	 */
	public String getFileName () {
		return fileName;
	} // getFileName ()
	
	public int getFileLength () {
		return fileLength;
	} // getFileLength ()
	
	public int getParts () {
		return parts;
	} // getParts ()
	
	public boolean isMD5 () {
		return md5;
	} // isMD5 ()
	
	/*
	 * Events methods :
	 */
	protected void fireEnginePartEnded (int next) {
		DefaultEngineListener.getInstance ().enginePartEnded (next);
	} // fireEnginePartEnded ()

	protected void fireEngineEnded () {
		DefaultEngineListener.getInstance ().engineEnded ();
	} // fireEngineEnded ()

	protected void fireEngineError (EngineException exc) {
		DefaultEngineListener.getInstance ().engineError (exc);
	} // fireEngineError ()
	
	protected void fireEngineDone (long readed) {
		DefaultEngineListener.getInstance ().engineDone (readed);
	} // fireEngineReaded ()
} // DefaultStickEngine