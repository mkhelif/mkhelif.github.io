package com.mkhelif.jsplit.engine.stick;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author Marwan KHELIF
 */
public class KFK extends DefaultStickEngine {
	
	public KFK (File file) {
		super (file);
	} // KFK ()
	
	protected void loadHeaders () throws IOException, FileNotFoundException {
		File[] files = new File (file.getAbsolutePath ().replace (file.getName (), "")).listFiles ();
		fileName = file.getName ().substring (0, file.getName ().lastIndexOf ("."));
		
		// Calculate parts and length :
		for (int i = 0 ; i < files.length ; i++) {
			if (files[i].getName ().startsWith (fileName + ".kk")) {
				parts++;
				fileLength += files[i].length ();
			}
		}
		if (parts != -1) {
			parts++;
		}
		
		fileName = file.getAbsolutePath ().replace (file.getName (), "") + fileName;
	} // loadHeaders ()

	public void stick () throws IOException, FileNotFoundException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream (getFileName ());
			fireEnginePartEnded (1);
			for (int i = 0 ; i < getParts () ; ) {
				RandomAccessFile access = new RandomAccessFile (fileName + ".kk" + i, "r");
				long read = 0;
				long length = access.length ();
				
				// Stick :
				while (read < length) {
					if (paused) {
						try { mutex.wait (); } catch (InterruptedException e) {}
					}
					
					byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
					access.read (buffer);
					out.write (buffer);
					read += buffer.length;
					fireEngineDone (buffer.length);
					Thread.yield ();
				}
				
				access.close ();
				fireEnginePartEnded (((++i + 1) > getParts () ? -1 : i + 1));
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { out.close (); } catch (IOException e) {}
		}
	} // stick ()
} // KFK