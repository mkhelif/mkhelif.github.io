package com.mkhelif.jsplit.engine.split;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import com.mkhelif.jsplit.engine.ByteUtils;

/**
 * @author Marwan KHELIF
 */
public class XtremSplit extends DefaultSplitEngine {

	public XtremSplit (File file, int parts) {
		super (file, parts);
	} // XtremSplit ()
	
	public void split () throws IOException, FileNotFoundException {
		RandomAccessFile toSplit = null;
		try {
			toSplit = new RandomAccessFile (file, "r");
			int length = (int) (file.length () / parts);
			for (int i = 1 ; i <= parts ; ) {
				RandomAccessFile access = null;
				try {
					String current = (i >= 100 ? String.valueOf (i) : (i >= 10 ? "0" + i : "00" + i));
					access = new RandomAccessFile (file.getAbsolutePath ().replace (file.getName (), "") + file.getName () + "." + current + ".xtm", "rw");
					int read = 0;
					
					if (i == 1) {
						writeHeaders (access);
						read += 104;
						fireEngineDone (104);
					}
					
					while (read < length) {
						if (paused) {
							try { mutex.wait (); } catch (InterruptedException e) {}
						}
						
						byte[] buffer = new byte[(BUFFER > length - read ? (int) (length - read) : BUFFER)];
						toSplit.read (buffer);
						access.write (buffer);
						read += buffer.length;
						fireEngineDone (buffer.length);
					}
					
					fireEnginePartEnded ((++i > parts ? -1 : i));
				} catch (FileNotFoundException e) {
					throw e;
				} catch (IOException e) {
					throw e;
				} finally {
					try { access.close (); } catch (IOException e) {}
				}
			}
			fireEngineEnded ();
		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try { toSplit.close (); } catch (IOException e) {}
		}
	} // split ()
	
	private void writeHeaders (RandomAccessFile access) throws IOException {
		// Write Program name :
		access.writeByte ("Xtremsplit".length ());
		access.write ("Xtremsplit".getBytes ());
		for (int j = "Xtremsplit".length () ; j < 20 ; j++) {
			access.write (0);
		}
		
		// Write Version :
		access.writeByte ("1.1".length ());
		access.write ("1.1".getBytes ());
		for (int j = "1.1".length () ; j < 14 ; j++) {
			access.write (0);
		}
		
		// Write Date : don't know how to write the right date in 4bytes...
		access.writeInt (0);
		
		// Write original filename :
		access.writeByte (file.getName ().length ());
		if (file.getName ().length () > 50) {
			access.write (file.getName ().substring (0, 50).getBytes ());
		} else {
			access.write (file.getName ().getBytes ());
			for (int j = file.getName ().length () ; j < 50 ; j++) {
				access.write (0);
			}
		}
		
		// Write if using MD5 :
		access.writeBoolean (false);
		
		// Write number of files :
		access.write (ByteUtils.toBytes (parts));

		// Write file size :
		access.write (ByteUtils.toBytes (file.length ()));
	} // writeHeaders ()
} // XtremSplit