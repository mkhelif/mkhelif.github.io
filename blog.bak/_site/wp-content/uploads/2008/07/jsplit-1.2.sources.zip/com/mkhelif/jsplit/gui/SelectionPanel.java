package com.mkhelif.jsplit.gui;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import com.mkhelif.jsplit.I18nManager;
import com.mkhelif.jsplit.gui.action.SplitAction;
import com.mkhelif.jsplit.gui.action.StickAction;

/**
 * @author Marwan KHELIF
 */
public class SelectionPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private JPanel selection = null;
	private JRadioButton stick = null;
	private JRadioButton split = null;

	private JPanel filePanel = null;
	private JTextField file = null;
	private JButton select = null;
	
	public SelectionPanel () {
		super ();
		initialize ();
	} // SelectionPanel ()
	
	private void initialize () {
		this.setLayout (new GridBagLayout ());
		GridBagConstraints c = new GridBagConstraints ();
		c.fill = GridBagConstraints.HORIZONTAL;
		
		c.gridy = 0;
		this.add (getSelection (), c);
		
		c.gridy = 1;
		c.weightx = 1;
		this.add (new JSeparator (), c);
		
		c.gridy = 2;
		c.weightx = 0;
		this.add (getFilePanel (), c);
	} // initialize ()
	
	public JPanel getSelection () {
		if (selection == null) {
			selection = new JPanel (new FlowLayout (FlowLayout.LEFT));
			selection.add (new JLabel (i18n ("action"), JLabel.LEFT));
			
			ButtonGroup group = new ButtonGroup ();
			group.add (getSplit ());
			group.add (getStick ());
			group.setSelected (getSplit ().getModel (), true);
			
			selection.add (getSplit ());
			selection.add (getStick ());
		}
		return selection;
	} // getSelection ()
	
	public JPanel getFilePanel () {
		if (filePanel == null) {
			filePanel = new JPanel (new GridBagLayout ());
			GridBagConstraints c = new GridBagConstraints ();
	        c.anchor = GridBagConstraints.NORTHWEST;
	        c.fill = GridBagConstraints.HORIZONTAL;
	        
	        c.weightx = 0;
	        c.insets = new Insets (7, 5, 0, 2);
			filePanel.add (new JLabel (i18n ("split.file"), JLabel.RIGHT), c);
			
			c.weightx = 1;
	        c.insets = new Insets (5, 0, 0, 2);
			filePanel.add (getFile (), c);
			
			c.weightx = 0;
	        c.insets = new Insets (5, 0, 0, 5);
			filePanel.add (getSelect (), c);
		}
		return filePanel;
	} // getFilePanel ()
	
	public JRadioButton getSplit () {
		if (split == null) {
			split = new JRadioButton (i18n ("split"));
			split.addActionListener (new ActionListener () {
				public void actionPerformed (ActionEvent arg0) {
					Workbench.getInstance ().getStick ().setVisible (false);
					Workbench.getInstance ().getSplit ().setVisible (true);
					
					Workbench.getInstance ().getBottom ().getGo ().setAction (new SplitAction ());
					Workbench.getInstance ().getProgress ().setString ("");
					Workbench.getInstance ().getProgress ().setValue (0);

					Workbench.getInstance ().getInfos ().setTitle (i18n ("infos.split.title"));
					Workbench.getInstance ().getInfos ().setInfo  (i18n ("infos.split.info"));
				} // actionPerformed ()
			});
		}
		return split;
	} // getSplit ()
	
	public JRadioButton getStick () {
		if (stick == null) {
			stick = new JRadioButton (i18n ("stick"));
			stick.addActionListener (new ActionListener () {
				public void actionPerformed (ActionEvent arg0) {
					Workbench.getInstance ().getStick ().load (new File (file.getText ()));
					
					Workbench.getInstance ().getSplit ().setVisible (false);
					Workbench.getInstance ().getStick ().setVisible (true);
					
					Workbench.getInstance ().getBottom ().getGo ().setAction (new StickAction ());
					Workbench.getInstance ().getProgress ().setString ("");
					Workbench.getInstance ().getProgress ().setValue (0);
					
					Workbench.getInstance ().getInfos ().setTitle (i18n ("infos.stick.title"));
					Workbench.getInstance ().getInfos ().setInfo  (i18n ("infos.stick.info"));
				} // actionPerformed ()
			});
		}
		return stick;
	} // getStick ()
	
	public JTextField getFile () {
		if (file == null) {
			file = new JTextField ();
		}
		return file;
	} // getFile ()
	
	public JButton getSelect() {
		if (select == null) {
			select = new JButton ("...");
			select.setMargin (new Insets (0, 3, 0, 2));
			select.addActionListener (new ActionListener () {
				public void actionPerformed (ActionEvent arg0) {
					JFileChooser chooser = new JFileChooser ();
					chooser.setMultiSelectionEnabled (false);
					
					int c = chooser.showOpenDialog (Workbench.getInstance ());
					if (c == JFileChooser.APPROVE_OPTION) {
						File fic = chooser.getSelectedFile ();
						getFile ().setText (fic.getAbsolutePath ());
						
						// Load file headers :
	                    if (Workbench.getInstance ().getSelection ().getStick ().isSelected ()) {
	                    	Workbench.getInstance ().getStick ().load (fic);
	                    }
					}
				} // actionPerformed ()
			});
		}
		return select;
	} // getSelect ()
	
	public void setEnabled (boolean b) {
		getStick ().setEnabled (b);
		getSplit ().setEnabled (b);
		getFile ().setEnabled (b);
		getSelect ().setEnabled (b);
	} // setEnabled ()
	
	public String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.jsplit.gui.lang.workbench");
	} // i18n ()
} // SelectionPanel