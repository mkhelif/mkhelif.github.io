package com.mkhelif.jsplit.engine;

/**
 * @author Marwan KHELIF
 */
public interface Engine extends Runnable {
	public void run ();
	
	public void pause ();
	public void resume ();
} // Engine