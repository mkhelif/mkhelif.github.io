package com.mkhelif.hash.gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.dnd.DropTarget;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.TooManyListenersException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.UIManager;

import com.mkhelif.hash.I18nManager;
import com.mkhelif.hash.Launcher;

/**
 * <p>Main GUI class. It represents the displayed JFrame </p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class Workbench extends JFrame {
    private static final long serialVersionUID = 1L;

    /**
     * Singleton pattern.
     */
    private static Workbench workbench = null;
 
    /**
     * Component in this frame.
     */
    private TopInfoPanel infos = null;
 
    private SelectionPanel selection = null;
    private HashPanel hash = null;
    
    private JButton go = null;
    private JButton close = null;
    
    private Workbench () {
        super ("jHash");
        initialize ();
    } // Workbench ()
    
    public static Workbench getInstance () {
        if (workbench == null) {
            workbench = new Workbench ();
        }
        return workbench;
    } // getInstance ()
    
    /**
     * This method setup the frame by adding component.
     */
    private void initialize () {
    	// Change default LookAndFeel :
        try {
            UIManager.setLookAndFeel (UIManager.getSystemLookAndFeelClassName ());
        } catch (Exception e) {}
        
        // Layout components :
        this.setContentPane (new JPanel ());
        this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;

        c.insets = new Insets (0, 0, 0, 0);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 3;
        this.add (getInfos (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 3;
        this.add (getSelection (), c);
        
        c.insets = new Insets (2, 2, 2, 2);
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 3;
        this.add (new JSeparator (), c);
        
        c.insets = new Insets (0, 0, 0, 0);
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 3;
        this.add (getHash (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridy = 4;
        c.gridx = 0;
        c.gridwidth = 3;
        c.weighty = 1;
        this.add (new JPanel (), c);

        c.insets = new Insets (2, 2, 2, 2);
        c.gridy = 5;
        c.gridx = 0;
        c.gridwidth = 3;
        c.weighty = 0;
        this.add (new JSeparator (), c);

        c.insets = new Insets (0, 0, 0, 0);
        c.gridy = 6;
        c.gridx = 0;
        c.gridwidth = 1;
        this.add (new JPanel (), c);

        c.insets = new Insets (2, 0, 2, 2);
        c.gridy = 6;
        c.gridx = 1;
        c.weightx = 0;
        c.gridwidth = 1;
        this.add (getGo (), c);
        
        c.insets = new Insets (2, 0, 2, 2);
        c.gridy = 6;
        c.gridx = 2;
        this.add (getClose (), c);
        
        this.pack ();
        this.setLocationRelativeTo (null);
        this.addWindowListener (new WindowAdapter () {
            public void windowClosing (WindowEvent arg0) {
                Launcher.stop ();
            } // windowClosing ()
        });
        
        // Enable file Drag and Drop from system : 
        DropTarget target = new DropTarget ();
        try {
            target.addDropTargetListener (new SystemHandler ());
        } catch (TooManyListenersException e) {}
        this.setDropTarget(target);
    } // initialize ()

    public TopInfoPanel getInfos () {
        if (infos == null) {
            infos = new TopInfoPanel ();
            infos.setTitle (i18n ("topinfo.verify.title"));
            infos.setInfo (i18n ("topinfo.verify.info"));
        }
        return infos;
    } // getInfos ()
    
    public SelectionPanel getSelection () {
        if (selection == null) {
            selection = new SelectionPanel ();
        }
        return selection;
    } // getSelection ()
    
    public HashPanel getHash () {
        if (hash == null) {
            hash = new HashPanel ();
        }
        return hash;
    } // getHash ()
    
    public JButton getClose () {
        if (close == null) {
            close = new JButton (i18n ("close"));
            close.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent arg0) {
                    Launcher.stop ();
                } // actionPerformed ()
            });
        }
        return close;
    } // getClose ()
    
    public JButton getGo () {
        if (go == null) {
            go = new JButton (i18n ("verify"));
            go.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent arg0) {
                    perform ();
                } // actionPerformed ()
            });
        }
        return go;
    } // getGo ()
    
    /**
     * perform method calculate the file signature and check (if needed) that it's correct.
     */
    private void perform () {
        String result = null;
        try {
            result = Launcher.digest ();
        } catch (IOException e) {
            String file = new File (getHash ().getFile ().getText ()).getName ();
            JOptionPane.showConfirmDialog (Workbench.this, i18n ("error.io", new Object[] {file}), i18n ("error"), JOptionPane.DEFAULT_OPTION);
            return;
        } catch (IllegalArgumentException e) {
            JOptionPane.showConfirmDialog (Workbench.this, i18n ("error.file"), i18n ("error"), JOptionPane.DEFAULT_OPTION);
            return;
        }
        
        if (getSelection ().getVerifyButton ().isSelected ()) {
            if (getHash ().getHash ().getText ().equals (result)) {
                getHash ().getHash ().setBackground (new Color (200, 255, 200));
            } else {
                getHash ().getHash ().setBackground (new Color (255, 200, 200));
            }
        } else {
            getHash ().getHash ().setText (result);
        }
    } // perform ()

    public String i18n (String key) {
        return I18nManager.getInstance ().get (key, "com.mkhelif.hash.gui.lang.workbench");
    } // i18n ()
    
    public String i18n (String key, Object[] args) {
        return I18nManager.getInstance ().get (key, args, "com.mkhelif.hash.gui.lang.workbench");
    } // i18n ()
} // Workbench