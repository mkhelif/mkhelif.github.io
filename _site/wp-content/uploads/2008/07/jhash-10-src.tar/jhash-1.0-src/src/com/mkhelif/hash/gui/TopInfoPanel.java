package com.mkhelif.hash.gui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

/**
 * <p>TopInfoPanel represents the small white panel at top of the frame.</p>
 * <p>It allows to display some informations to user.</p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class TopInfoPanel extends JPanel {
    
    private static final long serialVersionUID = 1L;
       
    private JLabel titleLabel = null;
    private JLabel iconStatusLabel = null;
    private JLabel statusLabel = null;
    private JLabel decorationLabel = null;
        
    public TopInfoPanel () {
        super ();
        initialize();
    } // TopInfoPanel ()
    
    /**
     * This method setup the panel by adding component.
     */
    private void initialize () {
        JPanel firstLinePanel = new JPanel ();
        firstLinePanel.setName ("firstLinePanel");
        firstLinePanel.setLayout (new FlowLayout (FlowLayout.LEFT));
        firstLinePanel.setOpaque (false);
        firstLinePanel.add (getTitleLabel ());
        
        JPanel secondLinePanel = new JPanel ();
        secondLinePanel.setName ("secondLinePanel");
        secondLinePanel.setLayout (new FlowLayout (FlowLayout.LEFT));
        secondLinePanel.setOpaque (false);
        secondLinePanel.add (getIconStatusLabel ());
        secondLinePanel.add (getStatusLabel ());
    
        this.setLayout (new GridBagLayout ());
        this.setBackground (Color.WHITE);
        
        GridBagConstraints b = new GridBagConstraints ();
        b.weightx = 1.0;
        b.weighty = 2.0;
        b.fill = GridBagConstraints.BOTH;
        b.gridx = 0;
        b.gridy = 0;
        b.insets = new Insets (0, 10, 0, 10);
        this.add (firstLinePanel, b);
        b.gridy = 1;
        b.insets = new Insets (0, 10, 0, 10);
        this.add (secondLinePanel, b);
        
        b.gridx = 1;
        b.gridy = 0;
        b.gridheight = 2;
        b.anchor = GridBagConstraints.EAST;
        b.fill = GridBagConstraints.NONE;
        b.weightx = 0;
        this.decorationLabel=new JLabel ();
        this.decorationLabel.setIconTextGap (0);
        this.add (decorationLabel, b);
        
        EtchedBorder border = new EtchedBorder (EtchedBorder.LOWERED);
        this.setBorder (border);
    } // initialize ()
    
    public JLabel getTitleLabel () {
        if (titleLabel == null) {
            titleLabel = new JLabel ();
            titleLabel.setName ("titleLabel");
            Font originalFont = titleLabel.getFont ();
            titleLabel.setFont (new Font (originalFont.getName (), originalFont.getStyle () | Font.BOLD, originalFont.getSize ()));
        }
        return titleLabel;
    } // getTitleLabel ()

    private JLabel getStatusLabel() {
        if(statusLabel==null) {
            statusLabel = new JLabel ("", null, JLabel.CENTER);
            statusLabel.setFont (new Font ("", Font.PLAIN, 12));
            statusLabel.setName ("statusLabel");
        }
        return statusLabel;
    } // getStatusLabel ()

    private JLabel getIconStatusLabel () {
        if(iconStatusLabel==null) {
            iconStatusLabel = new JLabel ("", JLabel.CENTER);
            iconStatusLabel.setName ("iconStatusLabel");
        }
        return iconStatusLabel;
    } // getIconStatusLabel ()
    
    /**
     * Display the given text and change the icon.
     * @param text Text to display.
     */
    public void setError (String text) {
        getIconStatusLabel ().setIcon (new ImageIcon (getClass ().getResource ("images/error.gif")));
        getStatusLabel ().setText (text);
    } // setError ()

    /**
     * Display the given text and change the icon.
     * @param text Text to display.
     */
    public void setInfo (String text) {
        getIconStatusLabel ().setIcon (new ImageIcon (getClass ().getResource ("images/info.gif")));
        getStatusLabel ().setText (text);
    } // setInfo ()

    /**
     * Display the given text and change the icon.
     * @param text Text to display.
     */
    public void setWarning (String text) {
        getIconStatusLabel ().setIcon (new ImageIcon (getClass ().getResource ("images/warning.gif")));
        getStatusLabel ().setText (text);
    } // setWarning ()
    
    /**
     * Display the given title.
     * @param title Title to display.
     */
    public void setTitle (String title) {
        getTitleLabel ().setText (title);
    } // setTitle ()
} // TopInfoPanel