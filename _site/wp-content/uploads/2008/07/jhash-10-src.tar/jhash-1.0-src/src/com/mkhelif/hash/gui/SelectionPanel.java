package com.mkhelif.hash.gui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import com.mkhelif.hash.I18nManager;

/**
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class SelectionPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JLabel action = null;
    private ButtonGroup group = null;
    private JRadioButton calculateButton = null;
    private JRadioButton verifyButton = null;

    private JLabel algo = null;
    private JComboBox algos = null;
    
    public SelectionPanel () {
        super ();
        initialize ();
    } // SelectionPanel ()
    
    private void initialize () {
        this.setLayout (new FlowLayout (FlowLayout.LEFT));
                
        group = new ButtonGroup ();
        group.add (getVerifyButton ());
        group.add (getCalculateButton ());
        group.setSelected (getVerifyButton ().getModel (), true);
        
        this.add (getAction ());
        this.add (getVerifyButton ());
        this.add (getCalculateButton ());
        
        this.add (new JPanel ());
        
        this.add (getAlgoLabel ());
        this.add (getAlgos ());
    } // initialize ()
    
    public JLabel getAction () {
        if (action == null) {
            action = new JLabel (i18n ("action"));
        }
        return action;
    } // getAction ()
    
    public JRadioButton getCalculateButton () {
        if (calculateButton == null) {
            calculateButton = new JRadioButton (i18n ("calculate"));
            calculateButton.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent arg0) {
                    Workbench.getInstance ().getGo ().setText (i18n ("calculate"));
                    Workbench.getInstance ().getInfos ().setTitle (i18n ("topinfo.calculate.title"));
                    Workbench.getInstance ().getInfos ().setInfo (i18n ("topinfo.calculate.info"));
                    Workbench.getInstance ().getHash ().getHash ().setBackground (Color.WHITE);
                } // actionPerformed ()
            });
        }
        return calculateButton;
    } // getCalculateButton ()
    
    public JRadioButton getVerifyButton () {
        if (verifyButton == null) {
            verifyButton = new JRadioButton (i18n ("verify"));
            verifyButton.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent arg0) {
                    Workbench.getInstance ().getGo ().setText (i18n ("verify"));
                    Workbench.getInstance ().getInfos ().setTitle (i18n ("topinfo.verify.title"));
                    Workbench.getInstance ().getInfos ().setInfo (i18n ("topinfo.verify.info"));
                    Workbench.getInstance ().getHash ().getHash ().setBackground (Color.WHITE);
                } // actionPerformed ()
            });
        }
        return verifyButton;
    } // getVerifyButton ()
    
    public JLabel getAlgoLabel () {
        if (algo == null) {
            algo = new JLabel (i18n ("algo"));
        }
        return algo;
    } // getAlgoLabel ()
    
    public JComboBox getAlgos () {
        if (algos == null) {
            algos = new JComboBox ();
            algos.addItem ("MD5");
            algos.addItem ("MD2");
            algos.addItem ("SHA-1");
            algos.addItem ("SHA-256");
            algos.addItem ("SHA-384");
            algos.addItem ("SHA-512");
        }
        return algos;
    } // getAlgos ()
    
    public String i18n (String key) {
        return I18nManager.getInstance ().get (key, "com.mkhelif.hash.gui.lang.workbench");
    } // i18n ()
} // SelectionPanel