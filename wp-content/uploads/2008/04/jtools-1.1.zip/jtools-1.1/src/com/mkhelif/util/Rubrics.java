package com.mkhelif.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>The Rubrics class represents a persistent set of properties stored in rubrics.</p>
 * <p>The Properties can be saved to a stream or loaded from a stream.</p>
 * <p>The rubric is a String whereas either key or its corresponding value are objects.</p>
 * <br>
 * <p>A Rubrics can contain another Rubrics as its "defaults";</p>
 * <p>this second Rubrics is searched if the property key is not found in the original Rubrics.</p> 
 * <br>
 * <p>It is allowed to use same keys in different rubrics.</p>
 * <br>
 * <p>Note that saving a Rubrics uses the toString() method of objects stored in it.
 * </p>As a concequence, saving Rubrics containing objects other than String is not usefull.</p>
 * 
 * @author Marwan KHELIF
 * @version Version 1.0 - 11/07/2007
 */
public class Rubrics implements Serializable {
	private static final long serialVersionUID = 1L;

	private static char[] hexDigit = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	private static final String CR = System.getProperty ("line.separator");

	private Map<String, Rubric> rubrics;
	private Rubrics defaults = null;

	private int initialCapacity;

	public Rubrics () {
		this (null, 50, 50);
	} // Rubrics ()
	
	public Rubrics (Rubrics defaults) {
		this (defaults, 50, 50);	
	} // Rubrice ()
	
	/**
	 * Creates a new Rubrics with the given capacities.
	 * @param initialCapacity initial capacity of Hashtables that contain rubrics.
	 * @param initialRubricCapacity initial capacity of Hashtables that are rubrics.
	 */	
	public Rubrics (int initialCapacity, int initialRubricCapacity) {
		this (null, initialCapacity, initialRubricCapacity);
	} // Rubrics ()
	 
	public Rubrics (Rubrics defaults, int initialCapacity, int initialRubricCapacity) {
		this.defaults=defaults;
	
		rubrics = new HashMap<String, Rubric> (initialCapacity);
		this.initialCapacity = initialRubricCapacity;
	} // Rubrics ()
		
	/**
	* <p>Returns the value to which the specified key is mapped in the hashtable for the given rubric. Check the default Rubrics if it has been set.</p>
	* 
	* @param rubricKey name of the rubric to search into
	* @param key key allowing to retreive the desired value in the hashtable.
	* @return <p>the value to which the key is mapped in this hashtable;</p>
	* <p>null if the key is not mapped to any value in the hashtable (rubric).</p>
	*/
	public String get (String rubricKey, String key) {
		Rubric rubric = rubrics.get (rubricKey);
		if (rubric == null) {
			return (defaults != null) ? defaults.get (rubricKey, key) : null;
		}
		String val =  rubric.get (key);
				
		return ((val == null) && (defaults != null)) ? defaults.get (rubricKey, key) : val;
	} // get ()
	
	/**
	 * <p>Gets the rubric with the given name.</p>
	 * <p>If not found, look for rubrics in default.</p>
	 * 
	 * @param key rubric's name.
	 */
	public Rubric getRubric (String key) {
		Rubric rubric = rubrics.get (key);
	
		return ((rubric == null) && (defaults != null)) ? defaults.getRubric (key) : rubric;
	} // getRubric ()
	
	/**
	 * <p>Return all rubric keys</p>
	 *
	 * @return rubric names
	 */
	public Set<String> getRubricKeys () {
		return rubrics.keySet ();
	} // getRubricKeys ()
	
	/**
	 * <p>Return the number of rubrics.</p>
	 *
	 * @return number of rubrics
	 */
	public int getRubricsSize () {
		return rubrics.size ();
	} // getRubricsSize ()
	
	/**
	 * <p>Gets all rubrics.</p>
	 * 
	 * @return a list of hashtables.
	 */
	public List<String> getRubrics () {
		List<String> vrubrics = new ArrayList<String> ();
		Iterator<String> rubricNames = rubrics.keySet ().iterator ();
		while (rubricNames.hasNext ()) {
			vrubrics.add (rubricNames.next ());
		}
		return vrubrics;
	} // getRubrics ()
	
	/**
	 * <p>Convenient method to retreive a String value in the Rubrics.</p>
	 * 
	 * @param rubricKey 
	 * @param key java.lang.String
	 * @return java.lang.String
	 */
	public String getString (String rubricKey, String key) {
		return (String) get (rubricKey,key);
	} // getString ()

	/**
	 * <p>Reads a property list (key and element pairs) from the input stream.</p>
	 * 
	 * @param in the input stream
	 * @throws IOException if an error occurred when reading from the input stream.
	 */
	public void load (Reader in) throws IOException {
		int buflen = 80;
		char[] buf = new char[buflen];
		int bufindx = 0;
		Rubric currentRubric = null;
		
		int ch = in.read ();
		while (true) {
	   		switch (ch) {
	   			case -1:
					return;
	
	   			case '#':
	   			case '!':
	   				while ((ch >= 0) && (ch != '\n') && (ch != '\r')) {
	   					ch = in.read();
	   				}
					continue;
					
				case '[':
				    char[] bufName = new char[buflen];
				    int index = 0;
				    while ((ch >= 0) && (ch != ']')) {
						ch = in.read ();
						if (index >= bufName.length) { 
							char[] buf2 = new char[bufName.length * 2]; 
							System.arraycopy (bufName, 0, buf2, 0, bufName.length);
							bufName = buf2;
						}
						bufName[index++]=(char)ch;
					} 
					ch = in.read ();
					String rubricName = new String (bufName, 0, index - 1);
					currentRubric = new Rubric ();
					rubrics.put (rubricName, currentRubric);
					continue;
					
	   			case '\n':
	   			case '\r':
	   			case ' ' :
	   			case '\t':
					ch = in.read ();
					continue;
					
	   			default:
	   				if (currentRubric == null) {
	   					while (ch != '[' && ch != -1) {
	   						ch = in.read ();
	   					}
	   					continue;
	   				}
	   		}
	
	  		// Read the key into buffer :
	  		bufindx = 0;
	   		while ((ch >= 0) && (ch != '=') && (ch != ':') && (ch != '\t') && (ch != '\n') && (ch != '\r')) {
				if (bufindx >= buflen) {
					buflen *= 2;
					char[] nbuf = new char[buflen];
					System.arraycopy (buf, 0, nbuf, 0, buf.length);
					buf = nbuf;
				}
				buf[bufindx++] = (char) ch;
				ch = in.read ();
	   		}
	   		while ((ch == ' ') || (ch == '\t')) {
				ch = in.read ();
	   		}
	   		if ((ch == '=') || (ch == ':')) {
				ch = in.read ();
	   		}
	   		while ((ch == ' ') || (ch == '\t')) {
				ch = in.read ();
	   		}
		    		
	   		// Create the key :
	   		String key = new String (buf, 0, bufindx);
	
	   		// Read the value into buffer :
	   		bufindx = 0;
	   		while ((ch >= 0) && (ch != '\n') && (ch != '\r')) {
				int next = 0;
				if (ch == '\\') {
					switch (ch = in.read ()) {
		  				case '\r':
							if (((ch = in.read()) == '\n') ||
		    						(ch == ' ') || (ch == '\t')) {
								// fall thru to '\n' case
							} else continue;
							
		  				case '\n': 
							while (((ch = in.read()) == ' ') || (ch == '\t'));
							continue;
							
		  				case 't': ch = '\t'; next = in.read (); break;
		  				case 'n': ch = '\n'; next = in.read (); break;
		  				case 'r': ch = '\r'; next = in.read (); break;
		  				case 'u': 
							while ((ch = in.read ()) == 'u');
							
							int d = 0;
			   				loop:
							for (int i = 0 ; i < 4 ; i++) {
				   				next = in.read ();
				   				switch (ch) {
				   					case '0': case '1': case '2': case '3': case '4':
				   					case '5': case '6': case '7': case '8': case '9':
										d = (d << 4) + ch - '0';
										break;
				   					case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
										d = (d << 4) + 10 + ch - 'a';
										break;
				   					case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
										d = (d << 4) + 10 + ch - 'A';
										break;
				   					default:
										break loop;
				   				}
				   				ch = next;
							}
							ch = d;
							break;
			   		
		  				default: next = in.read (); break;
			   		}
				} else {
			    	next = in.read ();
				}
				
				if (bufindx >= buflen) {
			  	  	buflen *= 2;
			   	 	char[] nbuf = new char[buflen];
			   	 	System.arraycopy (buf, 0, nbuf, 0, buf.length);
			   	 	buf = nbuf;
				}
				buf[bufindx++] = (char) ch;
				ch = next;
		    }
		    		
		    // Create the value :
		    String val = new String (buf, 0, bufindx);
	
		    if (currentRubric != null && bufindx >= 0) {
		    	currentRubric.put (key, val);
		    }
		}
	} // load ()
		
	/**
	 * <p>Maps the specified key to the specified value in the hashtable for the giben rubric.</p>
	 * <p>Neither the key nor the value can be null.</p>
	 * <p>If rubric doesn't exists, create it.</p>
	 * 
	 * @param rubricKey key of the rubric to search into.
	 * @param key the hashtable key.
	 * @param value the value
	 * @throws NullPointerException if the key or value is null.
	 */
	public void put (String rubricKey, String key, String value) {
		Rubric rubric = rubrics.get (rubricKey);
		if (rubric == null) {
			rubric = new Rubric (this.initialCapacity);
			putRubric (rubricKey, rubric);
		}
		rubric.put (key, value);
	} // put ()
	
	/**
	 * Removes the key (and its corresponding value) from the hashtable
	 * for the given rubric. This method does nothing if the key is
	 * not in the hashtable.
	 *
	 * @param rubricKey name of the rubric to search into.
	 * @param key the hashtable key.
	 * @return the removed object or null if key is not found.
	 */
	public String remove (String rubricKey, String key) {
		Rubric rubric = rubrics.get (rubricKey);
		if (rubric != null) {
			return rubric.remove (key);
		}
		return null;
	} // remove ()
	
	/**
	 * <p>Puts a new rubric. The given rubric name should not contain spaces.</p>
	 * 
	 * @param key rubric's name.
	 * @param values rubric's containt.
	 */
	public void putRubric (String key, Rubric values) {
		rubrics.put (key, values);
	} // putRubric ()
	
	/**
	 * <p>Removes the rubric with the given name.</p>
	 * 
	 * @param key the name of the rubric to remove.
	 */
	public void removeRubric (String key) {
		rubrics.remove (key);
	} // removeRubric ()
	
	/**
	 * <p>Writes this rubric list to the output stream in a format suitable for loading into a Properties table using the load method.</p>
	 * 
	 * @param out an output stream.
	 * @param header a description of the property list.
	 * @throws IOException if an error occurred when wrting to the output stream.
	 */
	public void save (Writer out, String header) throws IOException {
		if (header != null) {	    
			out.write ('#');	   
			out.write (header, 0, header.length ());
			out.write (CR);
		}
		out.write ('#');	
		String date = new Date ().toString ();
		out.write (date, 0, date.length ());
		out.write (CR); 
		out.write (CR); 
				
		Iterator<String> i2 = rubrics.keySet ().iterator ();
		while (i2.hasNext ()) {
			String rubricName = (String) i2.next ();
			Rubric rubric = rubrics.get (rubricName);
			
			// Write rubric header :
			String rubricHeader = "[" + rubricName + "]"; 
			out.write (rubricHeader, 0, rubricHeader.length ());
			out.write (CR);
			
			// Write keys/values :
			Iterator<String> i = rubric.keySet ().iterator ();
			for ( ; i.hasNext () ; ) {
				String key = (String) i.next ();
				out.write (key, 0, key.length ());
				out.write ('=');
				String val = rubric.get (key).toString ();
				int len = val.length ();
				boolean empty = false;
				
				for (int j = 0 ; j < len ; j++) {
					int ch = val.charAt (j);
					switch (ch) {
						case '\\': out.write ('\\'); out.write ('\\'); break;
						case '\t': out.write ('\\'); out.write ('t'); break;
						case '\n': out.write ('\\'); out.write ('n'); break;
						case '\r': out.write ('\\'); out.write ('r'); break;
						default:
							if ((ch < ' ') || (ch >= 127) || (empty && (ch == ' '))) {
								out.write ('\\');
								out.write ('u');
								out.write (toHex ((ch >> 12) & 0xF));
								out.write (toHex ((ch >>  8) & 0xF));
								out.write (toHex ((ch >>  4) & 0xF));
								out.write (toHex ((ch >>  0) & 0xF));
							} else {
								out.write (ch);
							}
					}
					empty = false;
				}
				out.write (CR);	
			}
			out.write (CR);
		}
		out.close ();
	} // save ()
	
	/**
	 * <p>Set the default rubric.</p>
	 * 
	 * @param defaults the new defaults rubric.
	 */
	public void setDefaults (Rubrics defaults) {
		this.defaults = defaults;
	} // setDefaults ()
	
	/**
	 * <p>Convert a nibble to a hex character</p>
	 *     
	 * @param nibble the nibble to convert.     
	 */    
	 private static char toHex (int nibble) {
		return hexDigit[(nibble & 0xF)];
	 } // toHex ()
	 
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString () {
	    StringBuilder result = new StringBuilder ("[");
		
		Iterator<String> rubricNames = rubrics.keySet ().iterator ();
		while (rubricNames.hasNext ()) {
			String rubricName = rubricNames.next ().toString ();
			result.append (rubricName);
			result.append (":");
			result.append (getRubric (rubricName).toString ());
			if (rubricNames.hasNext ()) {
				result.append (",");
			}
		}
	
		result.append ("]");
		return result.toString ();
	} // toString ()
} // Rubrics