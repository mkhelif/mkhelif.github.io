package com.mkhelif.swing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.swing.JComboBox;

/**
 * <p>Simple JComboBox that enable to select a locale.</p>
 * 
 * @author Marwan KHELIF
 * @version Version 1.0 - 03/07/2007
 */
public class JCountryBox extends JComboBox {
	private static final long serialVersionUID = 1L;

	private static final List<String> COUNTRIES = new ArrayList<String> ();
	
	/**
	 * <p>Initialize the countries list.</p>
	 */
	static {
		String[] countries = Locale.getISOCountries ();
	    for (int i = 0 ; i < countries.length ; i++) {
	    	Locale locale = new Locale (Locale.getDefault ().getLanguage (), countries[i]);
	    	countries[i] = locale.getDisplayCountry ();
	    }

	    // Order :
	    Arrays.sort (countries);
	    for (int i = 0 ; i < countries.length ; i++) {
	    	COUNTRIES.add (countries[i]);
	    }
	}
	
	/**
	 * <p>Constructor of JCountryBox</p>
	 */
	public JCountryBox () {
		super (COUNTRIES.toArray ());
		this.setSelectedItem (Locale.getDefault ().getDisplayCountry ());
	} // JCountryBox ()
	
	/**
	 * <p>Retreive the selected locale</p>
	 * @return the selected locale.
	 */
	public Locale getSelectedLocale () {
		return new Locale (Locale.getDefault ().getLanguage (), (String) this.getSelectedItem ());
	} // getSelectLocale ()
} // JCountryBox