package com.mkhelif.net;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * <p>DynamicClassLoader is a service that dynamically load JAR file into the application classpath.</p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 10/07/2007
 */
public class DynamicClassLoader {
	private static final Class[] parameters = new Class[] {URL.class};
	private static final URLClassLoader CLASS_LOADER = (URLClassLoader) ClassLoader.getSystemClassLoader ();
	
	/**
	 * <p>Dynamically load a jar file and add it to ClassPath.</p>
	 * 
	 * @param file - The jar file to load.
	 * @throws IOException
	 */
	public static void loadJAR (File file) throws IOException {
		DynamicClassLoader.loadJAR (new URL ("file:/" + file.getAbsolutePath ()));
	} // loadJAR ()
	
	/**
	 * <p>Dynamically load an url and add it to ClassPath.</p>
	 * 
	 * @param url - The url to load.
	 * @throws IOException
	 */
	public static void loadJAR (URL url) throws IOException {
		Class<?> sysclass = URLClassLoader.class;
		
		try {
			Method method = sysclass.getDeclaredMethod ("addURL", parameters);
			method.setAccessible (true);
			method.invoke (CLASS_LOADER, new Object[] {url});
		} catch (Exception e) {}
	} // loadJAR ()
} // DynamicClassLoader