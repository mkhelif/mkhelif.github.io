package com.mkhelif.swing.print;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.print.DocFlavor;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.Attribute;
import javax.print.attribute.standard.PrinterInfo;
import javax.print.attribute.standard.PrinterIsAcceptingJobs;
import javax.print.attribute.standard.PrinterMakeAndModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import com.mkhelif.I18nManager;
import com.mkhelif.swing.TopInfoPanel;

/**
 * @author Marwan KHELIF
 */
public class PrintDialog extends JDialog implements ItemListener {
	private static final long serialVersionUID = 1L;

	private JFrame parent = null;
	private TopInfoPanel infos = null;
	
	private JPanel printer = null;
	private JComboBox printers = null;
	private JLabel status = null;
	private JLabel type = null;
	private JLabel info = null;
	
	public PrintDialog (JFrame parent) {
		super (parent);
		
		this.parent = parent;
		initialize ();
		
		
		
		
		
		/*PrintService[] services = PrintServiceLookup.lookupPrintServices (null, null);
		for (int i = 0; i < services.length; i++) {
			PrintServiceAttributeSet set = services[i].getAttributes ();
			
			Class[] categories = services[i].getSupportedAttributeCategories();
			for (int j = 0; j < categories.length; j++) {
				System.out.print (categories[j].getSimpleName () + ": ");
				PrintServiceAttribute attr = (PrintServiceAttribute) set.get (categories[j]);
				if (attr == null) {
					System.out.println ("N/A");
					continue;
				}
				
				System.out.print (attr.getName () + " = ");
				TextSyntax te = (TextSyntax) attr;
				System.out.println (te.getValue ());
			}
		}*/
	/*	
		 PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);
		 PrintService svc = PrintServiceLookup.lookupDefaultPrintService();
		 PrintRequestAttributeSet attrs = new HashPrintRequestAttributeSet();
		 PrintService selection = ServiceUI.printDialog (null, 100, 100, services, svc, null, attrs); 
*/
		
		
		
		
	} // PrintDialog ()
	
	private void initialize () {
		this.setLayout (new GridBagLayout ());
		
		// Layout components :
		GridBagConstraints c = new GridBagConstraints ();
		c.anchor = GridBagConstraints.NORTHWEST;
		c.fill = GridBagConstraints.HORIZONTAL;

		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		this.add (getInfos (), c);

		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1;
		this.add (getPrinter (), c);
		
		// Dialog options :
		this.setTitle (i18n ("print.title"));
		this.setModal (true);
		this.pack ();
		this.setLocationRelativeTo (parent);
	} // initialize ()
	
	/*
	 * Components :
	 */
	private TopInfoPanel getInfos () {
		if (infos == null) {
			infos = new TopInfoPanel ();
			infos.setTitle (i18n ("print.infos.title"));
			infos.setInfo  (i18n ("print.infos.text"));
		}
		return infos;
	} // getInfos ()
	
	private JPanel getPrinter () {
		if (printer == null) {
			printer = new JPanel (new GridBagLayout ());
			printer.setBorder (new TitledBorder (i18n ("print.printer")));
			
			GridBagConstraints c = new GridBagConstraints ();
			c.anchor = GridBagConstraints.NORTHWEST;
			c.fill = GridBagConstraints.HORIZONTAL;
			
			c.gridx = 0;
			c.gridy = 0;
			c.weightx = 0;
			c.insets = new Insets (2, 5, 0, 5);
			printer.add (new JLabel (i18n ("print.printer.name"), JLabel.RIGHT), c);

			c.gridx = 1;
			c.gridy = 0;
			c.weightx = 1;
			c.insets = new Insets (0, 0, 0, 0);
			printer.add (getPrinters (), c);
			
			c.gridx = 0;
			c.gridy = 1;
			c.weightx = 0;
			c.insets = new Insets (5, 5, 0, 5);
			printer.add (new JLabel (i18n ("print.printer.state"), JLabel.RIGHT), c);

			c.gridx = 1;
			c.gridy = 1;
			c.weightx = 1;
			c.insets = new Insets (5, 0, 0, 0);
			printer.add (getStatus (), c);
			
			c.gridx = 0;
			c.gridy = 2;
			c.weightx = 0;
			c.insets = new Insets (5, 5, 0, 5);
			printer.add (new JLabel (i18n ("print.printer.type"), JLabel.RIGHT), c);

			c.gridx = 1;
			c.gridy = 2;
			c.weightx = 1;
			c.insets = new Insets (5, 0, 0, 0);
			printer.add (getType (), c);
			
			c.gridx = 0;
			c.gridy = 3;
			c.weightx = 0;
			c.insets = new Insets (5, 5, 0, 5);
			printer.add (new JLabel (i18n ("print.printer.info"), JLabel.RIGHT), c);

			c.gridx = 1;
			c.gridy = 3;
			c.weightx = 1;
			c.insets = new Insets (5, 0, 0, 0);
			printer.add (getInfo (), c);
		}
		return printer;
	} // getPrinter ()
	
	private JComboBox getPrinters () {
		if (printers == null) {
			printers = new JComboBox (PrintServiceLookup.lookupPrintServices (DocFlavor.INPUT_STREAM.AUTOSENSE, null));
			printers.addItemListener (this);
			printers.setRenderer (new DefaultListCellRenderer () {
				private static final long serialVersionUID = 1L;

				public Component getListCellRendererComponent (JList list, Object value, int row, boolean focus, boolean selected) {
					JLabel label = (JLabel) super.getListCellRendererComponent (list, value, row, focus, selected);
					label.setText (((PrintService) value).getName ());
					return label;
				} // getListCellRendererComponent ()
			});
		}
		return printers;
	} // getPrinters ()
	
	public JLabel getStatus () {
		if (status == null) {
			status = new JLabel ();
			
			Attribute att = ((PrintService) getPrinters ().getSelectedItem ()).getAttribute (PrinterIsAcceptingJobs.class);
            if (att != null) {
                status.setText (i18n (att.toString ()));
            }
		}
		return status;
	} // getStatus ()
	
	public JLabel getType() {
		if (type == null) {
			type = new JLabel ();
			
			Attribute att = ((PrintService) getPrinters ().getSelectedItem ()).getAttribute (PrinterMakeAndModel.class);
            if (att != null) {
            	type.setText (att.toString ());
            }
		}
		return type;
	} // getType ()
	
	public JLabel getInfo () {
		if (info == null) {
			info = new JLabel ();
			
			Attribute att = ((PrintService) getPrinters ().getSelectedItem ()).getAttribute (PrinterInfo.class);
            if (att != null) {
            	info.setText (att.toString ());
            }
		}
		return info;
	} // getInfo ()
	
	public void itemStateChanged (ItemEvent e) {
		PrintService service = (PrintService) getPrinters ().getSelectedItem ();
		if (service == null) {
			
			return;
		}
		Attribute att = null;
		
		// Status :
		att = service.getAttribute (PrinterIsAcceptingJobs.class);
        if (att != null) {
            status.setText (i18n (att.toString ()));
        }
        
        // Type :
		att = service.getAttribute (PrinterMakeAndModel.class);
        if (att != null) {
            type.setText (att.toString ());
        }
        
        // Info :
		att = service.getAttribute (PrinterInfo.class);
        if (att != null) {
            info.setText (att.toString ());
        }
	} // itemStateChanged ()
	
	/**
	 * <p>Retreive a localized message by this key.</p>
	 * 
	 * @param key of the properties file.
	 * @return The localiezed message corresponding to this key.
	 */
	private String i18n (String key) {
		return I18nManager.getInstance ().get (key, "com.mkhelif.swing.print.print");
	} // i18n ()
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] ar) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {}
		
		JFrame a = new JFrame();
		a.setVisible(true);
		
		new PrintDialog(a).setVisible(true);
	}
} // PrintDialog