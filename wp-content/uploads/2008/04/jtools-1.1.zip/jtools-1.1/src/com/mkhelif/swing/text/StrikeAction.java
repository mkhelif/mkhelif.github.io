package com.mkhelif.swing.text;

import java.awt.event.ActionEvent;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.StyledEditorKit.StyledTextAction;

public class StrikeAction extends StyledTextAction {
    private static final long serialVersionUID = 1L;

    public StrikeAction () {
        super ("font-strike");
    } // StrikeAction ()

    public void actionPerformed (ActionEvent evt) {
        JEditorPane editor = getEditor (evt);
        if (editor != null) {
            StyledEditorKit kit = getStyledEditorKit (editor);
            MutableAttributeSet attr = kit.getInputAttributes ();
            SimpleAttributeSet sas = new SimpleAttributeSet ();
            boolean strike = !StyleConstants.isStrikeThrough (attr);
            StyleConstants.setStrikeThrough (sas, strike);
            setCharacterAttributes (editor, sas, false);
        }
    } // actionPerformed ()
} // StrikeAction