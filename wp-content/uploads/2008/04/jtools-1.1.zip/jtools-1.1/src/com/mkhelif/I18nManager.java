package com.mkhelif;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * <p>I18nManager is a service that load language files.</p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class I18nManager {  
    
    /**
     * Singleton pattern.
     */
    private static I18nManager manager = null;
    
    private Locale locale = Locale.getDefault ();
    private ResourceBundle resource = null;
    
    private I18nManager () {
        this.locale = Locale.getDefault ();
    } // I18nManager ()
    
    public static I18nManager getInstance () {
        if (manager == null) {
            manager = new I18nManager ();
        }
        return manager;
    } // getInstance ()
    
    /**
     * setLanguage method modify the current displaying language.
     * @param lang The new GUI language.
     */
    public void setLanguage (String lang) {
        this.locale = new Locale (lang);
    } // setLanguage ()
    
    /**
     * setLocale method modify the current displaying language.
     * @param code The new GUI language code.
     */
    public void setLocale (String code) {
        this.locale = new Locale (code);
    } // setLocale ()
    
    public Locale getLocale () {
		return locale;
	} // getLocale ()
    
    /**
     * get method return the localized String associated to key.
     * @param key The key that we want a traduction.
     * @param bundle The target ResourceBundle.
     * @return The localized string.
     */
    public String get (String key, String bundle) {
        resource = ResourceBundle.getBundle (bundle, locale);
        if (resource == null) {
            resource = ResourceBundle.getBundle (bundle, Locale.ENGLISH);
        }
        return resource.getString (key);
    } // get ()
    
    /**
     * get method return the localized String associated to key.
     * @param key The key that we want a traduction.
     * @param args Arguments we want to find in localized String.
     * @param bundle The target ResourceBundle.
     * @return The localized string.
     */
    public String get (String key, Object[] args, String bundle) {
        resource = ResourceBundle.getBundle (bundle, locale);
        if (resource == null) {
            resource = ResourceBundle.getBundle (bundle, Locale.ENGLISH);
        }
        String pattern = resource.getString (key);
        return MessageFormat.format (pattern, args);
    } // get ()
} // I18nManager