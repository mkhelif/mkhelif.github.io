package com.mkhelif.swing;

import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.mkhelif.IconManager;

/**
 * @author Marwan KHELIF
 */
public class JRank extends JPanel implements MouseListener, MouseMotionListener {
	private static final long serialVersionUID = 1L;

	private static ImageIcon RANK_HOVER      = new ImageIcon (IconManager.getInstance ().get ("com/mkhelif/resources/rank/hover.png"));
	private static ImageIcon RANK_SELECTED   = new ImageIcon (IconManager.getInstance ().get ("com/mkhelif/resources/rank/select.png"));
	private static ImageIcon RANK_UNSELECTED = new ImageIcon (IconManager.getInstance ().get ("com/mkhelif/resources/rank/unselect.png"));
	
	private JLabel[] labels = null;
	private int rank = 0;
	
	/**
	 * <p>Default constructor : initialize with 5 stars.</p>
	 */
	public JRank () {
		this (5);
	} // JRank ()
	
	/**
	 * <p>JRank constructor : initialize with <b>max</b> stars.</p>
	 * @param max - Number of stars to display.
	 */
	public JRank (int max) {
		super ();
		
		this.rank  = 0;
		this.labels = new JLabel[max];
		this.initialize ();
	} // JRank ()
	
	private void initialize () {
		// Add default label :
		for (int i = 0 ; i < labels.length ; i++) {
			labels[i] = new JLabel (RANK_UNSELECTED);
			this.add (labels[i]);
		}

		this.addMouseListener (this);
		this.addMouseMotionListener (this);
	} // initialize ()

	/**
	 * <p>Retreive the selected rank</p>
	 * 
	 * @return The selected rank
	 */
	public int getRank () {
		return rank;
	} // getRank ()
	
	/*
	 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
	 */
	public void mouseMoved (MouseEvent e) {
		int rank = e.getX () / (16 + 5);
		if (rank >= this.labels.length) {
			return;
		}
		
		// Set unselected icon :
		for (int i = this.rank + 1 ; i < labels.length ; i++) {
			labels[i].setIcon (RANK_UNSELECTED);
			labels[i].repaint ();
		}
		
		// Set selected icon :
		for (int i = 0 ; i <= this.rank ; i++) {
			labels[i].setIcon (RANK_SELECTED);
			labels[i].repaint ();
		}
		
		// Set hover icon :
		for (int i = 0 ; i <= rank ; i++) {
			labels[i].setIcon (RANK_HOVER);
			labels[i].repaint ();
		}
		
		this.repaint ();
	} // mouseMoved ()
	
	/*
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited   (MouseEvent e) {
		// Set selected icon :
		for (int i = 0 ; i <= this.rank ; i++) {
			labels[i].setIcon (RANK_SELECTED);
			labels[i].repaint ();
		}

		// Set nselected icon :
		for (int i = this.rank + 1 ; i < this.labels.length ; i++) {
			labels[i].setIcon (RANK_UNSELECTED);
			labels[i].repaint ();
		}
	} // mouseExited ()
	
	/*
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed  (MouseEvent e) {
		this.rank = e.getX () / (16 + ((FlowLayout) this.getLayout ()).getHgap ());	
	} // mousePressed ()
	
	/*
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased (MouseEvent e) {} // mouseReleased ()
	
	/*
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked  (MouseEvent e) {} // mouseClicked  ()
	
	/*
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered  (MouseEvent e) {} // mouseEntered  ()
	
	/*
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	public void mouseDragged  (MouseEvent e) {} // mouseDragged  ()
} // JRank