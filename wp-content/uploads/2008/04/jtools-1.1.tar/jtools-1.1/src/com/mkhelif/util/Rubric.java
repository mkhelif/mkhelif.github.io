package com.mkhelif.util;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>A simple extension of HashMap<String, String></p>
 * 
 * @author Marwan KHELIF
 * @version Version 1.0 - 11/07/2007
 */
public class Rubric extends HashMap<String, String> {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructors from superclass :
	 */
	public Rubric () {
		super ();
	} // Rubric ()
	
	public Rubric (int initialCapacity, float loadFactor) {
		super (initialCapacity, loadFactor);
	} // Rubric ()

	public Rubric (int initialCapacity) {
		super (initialCapacity);
	} // Rubric ()

	public Rubric (Map<? extends String, ? extends String> m) {
		super (m);
	} // Rubric ()
	
	/**
	 * <p>Return the <b>int</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>int</b> value associated with the key if exists or defaultValue
	 */
	public int getInt (String key, int defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Integer.parseInt (super.get (key));
	} // getInt ()

	/**
	 * <p>Return the <b>double</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>double</b> value associated with the key if exists or defaultValue
	 */
	public double getDouble (String key, double defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Double.parseDouble (super.get (key));
	} // getDouble ()

	/**
	 * <p>Return the <b>float</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>float</b> value associated with the key if exists or defaultValue
	 */
	public float getFloat (String key, float defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Float.parseFloat (super.get (key));
	} // getFloat ()

	/**
	 * <p>Return the <b>short</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>short</b> value associated with the key if exists or defaultValue
	 */
	public short getShort (String key, short defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Short.parseShort (super.get (key));
	} // getShort ()

	/**
	 * <p>Return the <b>long</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>long</b> value associated with the key if exists or defaultValue
	 */
	public long getLong (String key, long defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Long.parseLong (super.get (key));
	} // getLong ()

	/**
	 * <p>Return the <b>byte</b> value associated with the key.</p>
	 * 
	 * @param key
	 * @param defaultValue
	 * @return The <b>byte</b> value associated with the key if exists or defaultValue
	 */
	public byte getByte (String key, byte defaultValue) {
		if (!super.containsKey (key)) {
			return defaultValue;
		}
		return Byte.parseByte (super.get (key));
	} // getByte ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putInt (String key, int value) {
		return super.put (key, String.valueOf (value));
	} // putInt ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putDouble (String key, double value) {
		return super.put (key, String.valueOf (value));
	} // putDouble ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putFloat (String key, float value) {
		return super.put (key, String.valueOf (value));
	} // putFloat ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putByte (String key, byte value) {
		return super.put (key, String.valueOf (value));
	} // putByte ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putShort (String key, short value) {
		return super.put (key, String.valueOf (value));
	} // putShort ()

	/**
	 * <p>Associates the specified value with the specified key</p>
	 * 
	 * @param key key with which the specified value is to be associated
	 * @param value value to be associated with the specified key
	 * @return The previous value associated with key, or null if there was no mapping for key
	 */
	public String putLong (String key, long value) {
		return super.put (key, String.valueOf (value));
	} // putLong ()
} // Rubric