package com.mkhelif.swing.text;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import com.mkhelif.I18nManager;
import com.mkhelif.IconManager;

/**
 * @author Marwan KHELIF
 */
class EditButton extends JButton {
	private static final long serialVersionUID = 1L;

	public EditButton (String text, String icon, Action action) {
		super (action);
		
		this.setIcon (new ImageIcon (IconManager.getInstance ().get (icon)));
		this.setToolTipText (I18nManager.getInstance ().get (text, ""));
	} // EditButton ()
} // EditButton