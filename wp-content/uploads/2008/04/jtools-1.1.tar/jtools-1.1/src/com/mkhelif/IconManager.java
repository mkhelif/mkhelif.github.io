package com.mkhelif;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;

/**
 * @author Marwan KHELIF
 */
public class IconManager {

	private static IconManager manager = null;
	private HashMap<String, BufferedImage> sprites = new HashMap<String, BufferedImage> ();
	
	private IconManager () {} // IconManager ()
	
	public static IconManager getInstance () {
		if (manager == null) {
			manager = new IconManager ();
		}
		return manager;
	} // getInstance ()
	
	public BufferedImage get (String key) {
		if (!sprites.containsKey (key)) {
			BufferedImage image = null;
			try {
				image = ImageIO.read (new File (key));
			} catch (Exception e) {
				try {
					image = ImageIO.read (getClass ().getResourceAsStream ("/" + key));
				} catch (IOException e1) {
					image = null;
				}
			}
			sprites.put (key, toCompatibleImage (image));
		}
		return sprites.get (key);
	} // get ()
	
	private BufferedImage toCompatibleImage (BufferedImage image) {
		GraphicsConfiguration gc = GraphicsEnvironment.getLocalGraphicsEnvironment ().getDefaultScreenDevice ().getDefaultConfiguration ();
        if (image.getColorModel ().equals (gc.getColorModel ())) {
            return image;
        }
 
        BufferedImage compatibleImage = gc.createCompatibleImage (image.getWidth (), image.getHeight (), image.getTransparency ());
        Graphics g = compatibleImage.getGraphics ();
        g.drawImage (image, 0, 0, null);
        g.dispose ();
 
        return compatibleImage;
    } // toCompatibleImage ()
	
	public static BufferedImage createCompatibleImage (int w, int h) {
		GraphicsConfiguration configuration = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
		return configuration.createCompatibleImage (w, h, BufferedImage.TYPE_INT_ARGB);
	} // createCompatibleImage ()
} // IconManager