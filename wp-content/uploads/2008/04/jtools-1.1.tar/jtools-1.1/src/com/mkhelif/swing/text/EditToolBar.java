package com.mkhelif.swing.text;

import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.text.StyledEditorKit.AlignmentAction;
import javax.swing.text.StyledEditorKit.FontFamilyAction;

/**
 * @author Marwan KHELIF
 */
public class EditToolBar extends JToolBar {
    private static final long serialVersionUID = 1L;

    private Map<String, FontFamilyAction> fontActions = new HashMap<String, FontFamilyAction> ();
    private JTextPane text 		 = null;
    private ActionMap actions 	 = null;
    private JButton clear 		 = null;
    private JButton copy 		 = null;
    private JButton cut 		 = null;
    private JButton paste 		 = null;
    private JButton bold 		 = null;
    private JButton italic 		 = null;
    private JButton underline 	 = null;
    private JButton strike 		 = null;
    private JButton left 		 = null;
    private JButton center 		 = null;
    private JButton right 		 = null;
    private JButton justify 	 = null;
    private JButton list 		 = null;
    private JButton number 		 = null;
    private JComboBox fontSize	 = null;
    private JComboBox fontFamily = null;

    EditToolBar (JTextPane text) {
    	super ();

        this.text = text;
        this.actions = text.getActionMap ();
        initialize ();
    } // EditToolBar ()
    
    private void initialize () {
        setFloatable (false);
        
        this.add (getClear ());
        this.addSeparator ();
        this.add (getCopy ());
        this.add (getCut ());
        this.add (getPaste ());
        this.addSeparator ();
        this.add (getBold ());
        this.add (getItalic ());
        this.add (getUnderline ());
        this.add (getStrike ());
        this.addSeparator ();
        this.add (getLeft ());
        this.add (getCenter ());
        this.add (getRight ());
        this.add (getJustify ());
        this.addSeparator ();
        this.add (getList ());
        this.add (getNumber ());
        this.addSeparator ();
        this.add (getFontSize ());
        this.add (new JPanel ());
        this.add (getFontFamily ());
    } // initialize ()

    /*
     * Component :
     */
    JButton getClear  () {
        if (clear == null) {
            clear = new EditButton ("edit.clear", "icons/mail_clear.png", new  AbstractAction () {
            	private static final long serialVersionUID = 1L;

				public void actionPerformed (ActionEvent e) {
					text.setText ("");
            	} // actionPerformed ()
            });
        }
        return clear;
    } // getClear ()

    JButton getCopy () {
        if (copy == null) {
            copy = new EditButton ("edit.copy", "icons/mail_copy.png", actions.get ("copy-to-clipboard"));
        }
        return copy;
    } // getCopy ()

    JButton getCut () {
        if (cut == null) {
            cut = new EditButton ("edit.cut", "icons/mail_cut.png", actions.get ("cut-to-clipboard"));
        }
        return cut;
    } // getItalic ()

    JButton getPaste () {
        if (paste == null) {
            paste = new EditButton ("edit.paste", "icons/mail_paste.png", actions.get ("paste-from-clipboard"));
        }
        return paste;
    } // getItalic ()

    JButton getBold () {
        if (bold == null) {
            bold = new EditButton ("edit.bold", "icons/mail_bold.png", actions.get ("font-bold"));
        }
        return bold;
    } // getItalic ()

    JButton getItalic () {
        if (italic == null) {
            italic = new EditButton ("edit.italic", "icons/mail_italic.png", actions.get ("font-italic"));
        }
        return italic;
    } // getItalic ()

    JButton getUnderline () {
        if (underline == null) {
            underline = new EditButton ("edit.underline", "icons/mail_underline.png", actions.get ("font-underline"));
        }
        return underline;
    } // getUnderline ()

    JButton getStrike () {
        if (strike == null) {
            strike = new EditButton ("edit.strike", "icons/mail_strike.png", new StrikeAction ());
        }
        return strike;
    } // getStrike ()

    JButton getLeft () {
        if (left == null) {
            left = new EditButton ("edit.left", "icons/mail_align_left.png", actions.get ("left-justify"));
        }
        return left;
    } // getLeft ()

    JButton getCenter () {
        if (center == null) {
            center = new EditButton ("edit.center", "icons/mail_align_center.png", actions.get ("center-justify"));
        }
        return center;
    } // getCenter ()

    JButton getRight () {
        if (right == null) {
            right = new EditButton ("edit.right", "icons/mail_align_right.png", actions.get ("right-justify"));
        }
        return right;
    } // getRight ()

    JButton getJustify () {
        if (justify == null) {
            justify = new EditButton ("edit.justify", "icons/mail_align_justify.png", new AlignmentAction ("fill-justify", 3));
        }
        return justify;
    } // getJustify ()

    JButton getList () {
        if (list == null) {
            list = new EditButton ("edit.list", "icons/mail_list.png", actions.get ("InsertUnorderedListItem"));
        }
        return list;
    } // getList ()

    JButton getNumber () {
        if (number == null) {
            number = new EditButton ("edit.number", "icons/mail_number.png", actions.get ("InsertOrderedListItem"));
        }
        return number;
    } // getNumber ()

    JComboBox getFontSize () {
        if (fontSize == null) {
            fontSize = new JComboBox (new Integer[] {Integer.valueOf (8), Integer.valueOf (10), Integer.valueOf (12), Integer.valueOf (14), Integer.valueOf (16), Integer.valueOf (18), Integer.valueOf (24), Integer.valueOf (36), Integer.valueOf (48)});
            fontSize.setSelectedItem(Integer.valueOf(14));
            fontSize.addActionListener (new  ActionListener () {
            	public void actionPerformed (ActionEvent e) {
            		
            	} // actionPerformed ()
            });
        }
        return fontSize;
    } // getFontSize ()

    JComboBox getFontFamily () {
        if (fontFamily == null) {
            String f[] = GraphicsEnvironment.getLocalGraphicsEnvironment ().getAvailableFontFamilyNames ();
            fontFamily = new JComboBox ();
            for (int i = 0 ; i < f.length ; i++) {
                if(!fontActions.containsKey (f[i])) {
                    fontFamily.addItem (f[i]);
                    fontActions.put (f[i], new FontFamilyAction ((new StringBuilder ("font-family-")).append (f[i].toLowerCase ()).toString (), f[i]));
                }
            }

            fontFamily.addActionListener (new  ActionListener () {
            	public void actionPerformed (ActionEvent e) {
            	} // actionPerformed ()
            });
            fontFamily.setSelectedItem (text.getFont ().getFamily ());
        }
        return fontFamily;
    } // getFontFamily ()
} // EditToolBar