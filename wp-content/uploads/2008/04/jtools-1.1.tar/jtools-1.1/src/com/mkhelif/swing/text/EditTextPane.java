package com.mkhelif.swing.text;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.CharArrayWriter;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

public class EditTextPane extends JPanel {

    private static final long serialVersionUID = 1L;
    private EditToolBar tools = null;
    private JTextPane text = null;
    private HTMLEditorKit edit = null;
    private HTMLDocument doc = null;

    public EditTextPane () {
    	super ();
        initialize ();
    } // EditTextPane ()

    private void initialize () {
        this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.fill = 1;
        
        c.gridy = 0;
        c.insets = new Insets (2, 5, 0, 5);
        this.add (getTools (), c);
        
        c.gridy = 1;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets (3, 5, 5, 5);
        this.add (new JScrollPane (getText ()), c);
    } // initialize ()

    private EditToolBar getTools () {
        if (tools == null) {
            tools = new EditToolBar (getText ());
        }
        return tools;
    } // getTools ()

    private JTextPane getText () {
        if (text == null) {
            text = new JTextPane ();
            text.setEditorKit (getEdit ());
            text.setDocument (getDoc ());
            text.setContentType ("text/html");
            text.setPreferredSize (new Dimension (400, 200));
        }
        return text;
    } // getText ()

    private HTMLEditorKit getEdit () {
        if (edit == null) {
            edit = new HTMLEditorKit ();
        }
        return edit;
    } // getEdit ()

    private HTMLDocument getDoc () {
        if (doc == null) {
            doc = (HTMLDocument) getEdit ().createDefaultDocument ();
        }
        return doc;
    } // getDoc ()

    public String getTextAsHTML () {
        CharArrayWriter writer = null;
        writer = new CharArrayWriter ();
        try {
            this.getText ().getEditorKit ().write (writer, getText ().getDocument (), 0, getText ().getDocument ().getLength ());
        } catch (Exception exception) {}
        return new String (writer.toCharArray ());
    } // getTextAsHTML ()

    public void setText (String text) {
        this.getText ().setText (text);
    } // setText ()
} // EditTextPane