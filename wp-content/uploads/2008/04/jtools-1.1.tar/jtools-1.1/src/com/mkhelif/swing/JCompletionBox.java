package com.mkhelif.swing;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;

/**
 * <p>JCompletionBox enable auto-completion on a JComboBox</p>
 * 
 * @author Marwan KHELIF
 * @version Version 1.0 - 03/07/2007
 */
public class JCompletionBox extends PlainDocument {
	private static final long serialVersionUID = 1L;
	
    private ComboBoxModel model;
    private JTextComponent editor;
    
    private boolean selecting = false;
    
    /**
     * <p>Enable auto-completion on a JComboBox</p>
     * 
     * @param comboBox - the JComboBox we want to add auto-completion.
     */
    public static void enableAutoCompletion (JComboBox comboBox) {
    	new JCompletionBox (comboBox);
    } // enableAutoCompletion ()
    
    /**
     * <p>Constructor of JCompletionBox</p>
     * @param comboBox the JComboBox we want to add auto-completion
     */
    private JCompletionBox (JComboBox comboBox) {
    	super ();
    	
        model = comboBox.getModel ();
        editor = (JTextComponent) comboBox.getEditor ().getEditorComponent ();

    	comboBox.setEditable (true);
    	((JTextComponent) comboBox.getEditor ().getEditorComponent ()).setDocument (this);
    } // JCompletionBox ()

    /*
     * @see javax.swing.text.AbstractDocument#remove(int, int)
     */
    public void remove (int offs, int len) throws BadLocationException {
        if (selecting) {
        	return;
        }
        super.remove (offs, len);
    } // remove ()
    
    /*
     * @see javax.swing.text.PlainDocument#insertString(int, java.lang.String, javax.swing.text.AttributeSet)
     */
    public void insertString (int offs, String str, AttributeSet a) throws BadLocationException {
        if (selecting) {
        	return;
        }
        super.insertString (offs, str, a);

        Object item = lookupItem (this.getText (0, this.getLength ()));
        this.setSelectedItem (item);
		if (item == null) {
			return;
		}
		
		this.setText (item.toString ());
		this.highlightCompletedText (offs + str.length ());
    } // insertString ()
    
    /**
     * <p>Replace the text in JComboBox textfield.</p>
     * 
     * @param text - The text to set on JComboBox textfield.
     * @throws BadLocationException
     */
    private void setText (String text) throws BadLocationException {
        super.remove (0, getLength ());
        super.insertString (0, text, null);
    } // setText ()
    
    /**
     * <p>Highlight from start to end of text</p>
     * 
     * @param start - Start of highlighting.
     */
    private void highlightCompletedText (int start) {
        editor.setSelectionStart (start);
        editor.setSelectionEnd (getLength());
    } // highlightCompletedText ()
    
    /**
     * <p>Select item on JComboBox.</p>
     * 
     * @param item - The item to select.
     */
    private void setSelectedItem (Object item) {
        selecting = true;
        model.setSelectedItem (item);
        selecting = false;
    } // setSelectedItem ()
    
    /**
     * <p>Search in JComboBox items to find one which match the pattern.</p>
     * 
     * @param pattern the pattern we are looking for.
     * @return the matching item or null if no item found.
     */
    private Object lookupItem (String pattern) {
        for (int i = 0, n = model.getSize () ; i < n ; i++) {
            Object currentItem = model.getElementAt (i);
            if (startsWithIgnoreCase (currentItem.toString (), pattern)) {
                return currentItem;
            }
        }
        return null;
    } // lookupItem ()
    
    /**
     * <p>Check if str1 starts with str2 ignoring case.</p>
     * 
     * @param str1
     * @param str2
     * @return true - if str1 starts with str2 ignoring case.
     */
    private boolean startsWithIgnoreCase (String str1, String str2) {
        return str1.toLowerCase ().startsWith (str2.toLowerCase ());
    } // startsWithIgnoreCase ()
} // JCompletionBox