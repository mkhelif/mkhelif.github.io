package com.mkhelif.hash;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.mkhelif.hash.gui.Workbench;

/**
 * <p>Main class of the jHash project. It can start/stop the GUI and generate file signature.</p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class Launcher {
	/**
	 * Default buffer size for file reading.
	 */
    public static final int BUFFER = 16384;
    
    /**
     * Launch GUI.
     */
    public static void start () {
        Workbench.getInstance ().setVisible (true);
    } // start ()
    
    /**
     * Stop GUI and exit JVM.
     */
    public static void stop () {
        Workbench.getInstance ().setVisible (false);
        
        System.exit (0);
    } // stop ()
    
    /**
     * digest method returns an hexadecimal String that represent the file signature.
     * @return Hexadecimal String representation of the signature given by selected algorithm.
     * @throws IOException - In case of file reading error.
     */
    public static String digest () throws IOException {
        // Create MessageDigest instance :
        String algo = Workbench.getInstance ().getSelection ().getAlgos ().getSelectedItem ().toString ();
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance (algo);
        } catch (NoSuchAlgorithmException e) {}
        
        // Open file :
        File file = new File (Workbench.getInstance ().getHash ().getFile ().getText ());
        if (!file.exists ()) {
            throw new IllegalArgumentException ();
        }
        FileInputStream fis = new FileInputStream (file);
                
        // Read file and update messagedigest :
        byte[] buffer;
        while (fis.available () > 0) {
            if (BUFFER > fis.available ()) {
                buffer = new byte[fis.available ()];
            } else {
                buffer = new byte[BUFFER];
            }
            fis.read (buffer);
            md.update (buffer);            
        }
        
        // Return calculated hash :
        fis.close ();
        return toHexString (md.digest ());
    } // digest ()
    
    /**
     * toHexString method convert a bytes array to String.
     * @param data
     * @return Hexadecimal string representation of the bytes array.
     */
    public static String toHexString (byte[] data) {
        if (data == null || data.length <= 0) {
            return null;
        }
        String values[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"};
        
        StringBuilder output = new StringBuilder ();
        for (int index = 0 ; index < data.length ; index++) {
            byte value = (byte) (data[index] & 0xf0);
            value = (byte) (value >>> 4);
            value = (byte) (value & 0x0f);
            output.append (values[(int) value]);
            value = (byte) (data[index] & 0x0f);
            output.append (values[(int) value]);
        }
        return output.toString ();
    } // toHexString ()

    /**
     * Main method of jHash project.
     */
    public static void main (String[] args) {
        Launcher.start ();
    } // main ()
} // Launcher