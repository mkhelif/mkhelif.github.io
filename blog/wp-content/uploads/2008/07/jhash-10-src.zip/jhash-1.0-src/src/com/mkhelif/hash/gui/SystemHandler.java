package com.mkhelif.hash.gui;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.io.File;
import java.util.List;

/**
 * <p>SystemHandler class enable to listen to system drag and drop into application.</p>
 * 
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class SystemHandler extends DropTargetAdapter {

    public SystemHandler () {
        super ();
    } // SystemHandler ()

    /**
     * drop method is called when an object is dropped into the application.
     */
    public void drop (DropTargetDropEvent e) {
        Transferable t = e.getTransferable();
        DataFlavor[] flavors = t.getTransferDataFlavors ();
        for (int i = 0 ; i < flavors.length ; i++) {
            if (flavors[i].isFlavorJavaFileListType ()) {
                e.acceptDrop (e.getDropAction ());
                Object object = null;
                try {
                    object = t.getTransferData (flavors[i]);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                List objects = (List) object;
                if (objects.size () > 0) {
                    File file = (File) objects.get (0);
                    Workbench.getInstance ().getHash ().getFile ().setText (file.getAbsolutePath ());
                }
            }
        }
    } // drop ()
} // SystemHandler