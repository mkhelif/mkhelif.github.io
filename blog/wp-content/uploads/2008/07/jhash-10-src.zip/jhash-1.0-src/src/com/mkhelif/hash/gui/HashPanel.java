package com.mkhelif.hash.gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.mkhelif.hash.I18nManager;

/**
 * @author Marwan KHELIF
 * @version Verison 1.0 - 27/02/2007
 */
public class HashPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JLabel filename = null;
    private JTextField file = null;
    private JButton select = null;

    private JLabel hashlabel = null;
    private JTextField hash = null;
    
    private JButton verify = null;
    
    public HashPanel () {
        super ();
        initialize ();
    } // HashPanel ()
    
    private void initialize () {
        this.setLayout (new GridBagLayout ());
        GridBagConstraints c = new GridBagConstraints ();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.NORTHWEST;

        c.insets = new Insets (3, 4, 2, 2);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        this.add (getFilename (), c);

        c.insets = new Insets (1, 0, 0, 0);
        c.weightx = 1;
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 5;
        this.add (getFile (), c);

        c.insets = new Insets (0, 2, 0, 4);
        c.weightx = 0;
        c.gridx = 6;
        c.gridy = 0;
        c.gridwidth = 1;
        this.add (getSelect (), c);
        
        c.insets = new Insets (6, 4, 2, 2);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        this.add (getHashLabel (), c);

        c.insets = new Insets (4, 0, 0, 0);
        c.weightx = 1;
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 5;
        this.add (getHash (), c);
        
        c.insets = new Insets (0, 0, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 10;
        c.weightx = 1;
        c.weighty = 1;
        this.add (new JPanel (), c);
    } // initialize ()
    
    public JLabel getFilename () {
        if (filename == null) {
            filename = new JLabel (i18n ("filename"), JLabel.RIGHT);
        }
        return filename;
    } // getFileName ()
    
    public JTextField getFile () {
        if (file == null) {
            file = new JTextField ();
        }
        return file;
    } // getFile ()
    
    public JButton getSelect () {
        if (select == null) {
            select = new JButton (i18n ("select"));
            select.setMargin (new Insets (1, 5, 2, 3));
            select.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent e) {
                    JFileChooser chooser = new JFileChooser ();
                    int choice = chooser.showOpenDialog (HashPanel.this);
                    if (choice == JFileChooser.APPROVE_OPTION) {
                        getFile ().setText (chooser.getSelectedFile ().getAbsolutePath ());
                        getHash ().setBackground (Color.WHITE);
                    }
                } // actionPerformed ()
            });
        }
        return select;
    } // getSelect ()
    
    public JLabel getHashLabel () {
        if (hashlabel == null) {
            hashlabel = new JLabel (i18n ("hash"), JLabel.RIGHT);
        }
        return hashlabel;
    } // getHashLabel ()
    
    public JTextField getHash () {
        if (hash == null) {
            hash = new JTextField ();
        }
        return hash;
    } // getHash ()
    
    public JButton getVerify () {
        if (verify == null) {
            verify = new JButton (i18n ("verify"));
            verify.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent e) {
                    
                } // actionPerformed ()
            });
        }
        return verify;
    } // getVerify ()
    
    public String i18n (String key) {
        return I18nManager.getInstance ().get (key, "com.mkhelif.hash.gui.lang.workbench");
    } // i18n ()
} // HashPanel